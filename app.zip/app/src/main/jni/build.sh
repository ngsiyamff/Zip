clear
/data/user/0/aidepro.top/no_backup/ndksupport-1710240003/android-ndk-aide/ndk-build
