#include <dirent.h>
#include "Server.h"
#include "Includes/Encrypt/oxorany_include.h"
#include <android/log.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <math.h>
#include <atomic>
#include <thread>
#include <stdarg.h>
#include <fstream>
#include <cmath> // For sqrt and pow
#include <cfloat> // For FLT_MAX


bool wasEnabled;
float originalValue;

uintptr_t LocalPlayer = 0;
Vector3 g_TargetDir = Vector3::Zero();

void SilentAimThread() {
    while (true) {
        if (!pPlayer.AimSilent) {
            std::this_thread::sleep_for(std::chrono::milliseconds(100)); 
            continue;
        }

        uintptr_t localP = LocalPlayer;
        Vector3 targetP = g_TargetDir;

        if (localP && targetP != Vector3::Zero()) {
            int mIsFiring = Read<int>(localP + offset::isFiring);
            if (mIsFiring > 0) {
                uintptr_t aimInfo = Read<uintptr_t>(localP + offset::hitObjAddress);
                if (aimInfo) {
                    Vector3 startPos = Read<Vector3>(aimInfo + offset::ammoBase);
                    Vector3 dir = targetP - startPos;
                    
                    Write<Vector3>(aimInfo + offset::g_HitObjInfo, dir);
                }
            }
        }
    }
}


void CreateDataList(Response& SendResponse) {
    if (Actived.activar) {
        SendResponse.PlayerCount = 0;
        
        uintptr_t gameFacadeOffset = offset::Intbase; 
        auto GameFacade_c = Read<uintptr_t>(libAddress + gameFacadeOffset);
        
        if (GameFacade_c) {
            auto P2 = Read<uintptr_t>(GameFacade_c + offset::Staticfield);
            if(P2) {
                auto BaseGame = Read<uintptr_t>(P2);
                if (BaseGame) {
                    auto m_Match = Read<uintptr_t>(BaseGame + offset::m_Match);
                    if (m_Match) {
                        auto MatchIsRunning = Read<int>(m_Match + offset::MatchIsRunning);
                        if(MatchIsRunning != 4 && MatchIsRunning != 0 && MatchIsRunning == 1) {
                            auto localPlayer = Read<uintptr_t>(m_Match + offset::localPlayer);
                            if (!localPlayer) {
                                auto CurrentObserve = Read<uintptr_t>(m_Match + offset::CurrentObserve);
                                if (CurrentObserve) {
                                    localPlayer = Read<uintptr_t>(CurrentObserve + offset::ObserverPlayer);
                                }
                            }
                            
                            if (localPlayer != 0) {
                                LocalPlayer = localPlayer;
                                
                                auto Ghost = localPlayer + offset::GhostHack;
                                if (pPlayer.ghosthack) {
                                    Write<bool>(Ghost, true);
                                } else {
                                    Write<bool>(Ghost, false);
                                }
                                
                                auto PlayerAttributes = Read<uintptr_t>(localPlayer + offset::PlayerAttributes);
                                if (PlayerAttributes) {
                                    auto ShootNoReload = PlayerAttributes + offset::ShootNoReload;
                                    if (pPlayer.NoRel) {
                                        Write<bool>(ShootNoReload, true);
                                    } else {
                                        Write<bool>(ShootNoReload, false);
                                    }
                                }
                                
                                auto InventoryManager = Read<uintptr_t>(localPlayer + offset::InventoryManager);
                                if (InventoryManager) {
                                    auto Item = Read<uintptr_t>(InventoryManager + offset::Item);
                                    if (Item) {
                                        auto WeaponComponent = Read<uintptr_t>(Item + offset::WeaponComponent);
                                        if (WeaponComponent) {
                                            uintptr_t NoRecoil = WeaponComponent + offset::NoRecoil;
                                            if (pPlayer.NoRec) {
                                                if (!wasEnabled) {
                                                    originalValue = Read<float>(NoRecoil);
                                                    wasEnabled = true;
                                                }
                                                Write<float>(NoRecoil, 0.0f);
                                            } else {
                                                if (wasEnabled) {
                                                    Write<float>(NoRecoil, originalValue);
                                                    wasEnabled = false;
                                                }
                                            }
                                        }
                                    }
                                }
                                                                                
                                auto FollowCamera = Read<uintptr_t>(localPlayer + offset::FollowCamera);
                                if (FollowCamera != 0) {
                                    auto Camera = Read<uintptr_t>(FollowCamera + offset::Camera);
                                    if (Camera != 0) {
                                        auto IntPtrCam = Read<uintptr_t>(Camera + offset::IntPtrCam);
                                        if (IntPtrCam != 0) {
                                            auto matrix = Read<D3DMatrix>(IntPtrCam + offset::Matrix);                       
                                            auto dictionary = Read<uintptr_t>(BaseGame + offset::Dictionary);
                                            if (dictionary) {
                                                auto entitylist = Read<uintptr_t>(dictionary + offset::entitylist);
                                                Vector3 LocalPosition = GetNodePosition(GetPlayerHeadTF(localPlayer));
                                                auto mIsFiring = Read<int>(localPlayer + offset::isFiring);
                                                auto CameraPosition = GetPosition(GetPlayerMainCamera(localPlayer));
                                                 
                                                // === AIMBOT VARIABLES (Loop er baire) ===
                                                float closestDistToCrosshair = FLT_MAX;
                                                Vector3 bestAimbotTarget = Vector3::Zero();
                                                bool foundValidTarget = false;
                                                uintptr_t bestEnemyListPtr = 0;
                                                
                                                // Assuming you have g_screenWidth and g_screenHeight globally defined
                                                float screenCenterX = g_screenWidth / 2.0f;
                                                float screenCenterY = g_screenHeight / 2.0f;
                                                // =========================================

                                                for (int i = 0; i < 1000; i++) {
                                                    auto enemyList = Read<uintptr_t>(entitylist + i * 8);
                                                    if (enemyList != 0) {
                                                        auto isClientBot = Read<bool>(enemyList + offset::IsClientBot);
                                                        if (isClientBot == 1 || isClientBot == 0) {
                                                            auto AvatarManager = Read<uintptr_t>(enemyList + offset::AvatarManager);
                                                            if (AvatarManager != 0 && enemyList != localPlayer) {
                                                                auto UmaAvatarSimple = Read<uintptr_t>(AvatarManager + offset::UmaAvatarSimple);
                                                                if (UmaAvatarSimple != 0) {
                                                                    auto IsVisible = Read<bool>(UmaAvatarSimple + offset::IsVisible);
                                                                    if (IsVisible == 1) {
                                                                        auto UmaData = Read<uintptr_t>(UmaAvatarSimple + offset::UmaData);
                                                                        if (UmaData != 0) {
                                                                            auto KHDMPGBLNCM = Read<uintptr_t>(enemyList + offset::KHDMPGBLNCM);
                                                                            if (KHDMPGBLNCM != 0) {
                                                                                bool isDieing = false;
                                                                                auto maybeDead = Read<uintptr_t>(KHDMPGBLNCM + offset::maybeDead);
                                                                                if (maybeDead && Read<int>(maybeDead + offset::isKnocked) == 8) isDieing = true;
                                                                                
                                                                                if (Read<bool>(UmaData + offset::UmaData_IsTeam) != 0) continue;
                                                                                if (Read<bool>(enemyList + offset::Player_isdead) != 0) continue;
                                                                                
                                                                                int Health = 0;
                                                                                auto GetCurHP = Read<uintptr_t>(enemyList + offset::GetCurHP);
                                                                                if (GetCurHP != 0) {
                                                                                    auto GetCur = Read<uintptr_t>(GetCurHP + offset::GetCur);
                                                                                    if (GetCur != 0) {
                                                                                        auto HP = Read<uintptr_t>(GetCur + offset::HP);
                                                                                        if (HP != 0) Health = (int)Read<short>(HP + offset::Health);
                                                                                    }
                                                                                }
                                                                                /*
                                                                                int weaponId = 0;
                                                                                auto inv = Read<uintptr_t>(enemyList + offset::InventoryManager);
                                                                                if (inv) {
                                                                                    auto item = Read<uintptr_t>(inv + offset::Item);
                                                                                    if (item) {
                                                                                        auto itemData = Read<uintptr_t>(item + offset::ItemData);
                                                                                        if (itemData) {
                                                                                            weaponId = Read<int>(itemData + offset::ItemData_WeaponId);
                                                                                        }
                                                                                    }
                                                                                }*/
                                                                                
                                                                                if (pPlayer.aimbotlock && !isDieing) {
                                                                                    auto HedColider = Read<uintptr_t>(enemyList + bone::HedColider);
                                                                                    if (HedColider) Write(enemyList + offset::Colider_Field, HedColider);
                                                                                }
                                                                                
                                                                                auto EnemyPosition = GetNodePosition(GetPlayerHeadTF(enemyList));
                                                                                auto EnemyPositionPe = GetNodePosition(GetPlayerPeTF(enemyList));
                                                                                
                                                                                if (LocalPosition == Vector3::Zero() || EnemyPosition == Vector3::Zero()) continue;
                                                                               
                                                                                float distanceToEnemy = Vector3::Distance(LocalPosition, EnemyPosition);
                                                                                auto screenPos = WorldToScreenPoint(matrix, EnemyPosition);
                                                                                float fovRadius = (pPlayer.AimFov / 360.0f) * (g_screenHeight / 2.0f);
                                                                                
                                                                                auto LocationHeadBox = WorldToScreenPoint(matrix, EnemyPosition);
                                                                                auto LocationToeBox = WorldToScreenPoint(matrix, EnemyPositionPe);
                                                                                if (LocationHeadBox.X < -0 || LocationToeBox.X < -0) continue;
                                                                                    
                                                                                // --- ESP DATA POPULATION ---
                                                                                auto *data = &SendResponse.Players[SendResponse.PlayerCount];
                                                                                    
                                                                                memset(data->PlayerName, 0, 64);
                                                                                if (isClientBot) {
                                                                                    strcpy(data->PlayerName, "Enemy");
                                                                                } else {
                                                                                    uintptr_t NamePtr = Read<uintptr_t>(enemyList + offset::NamePtr); 
                                                                                    if (NamePtr > 0x10000000) {
                                                                                        getUTF8(data->PlayerName, NamePtr);
                                                                                    }
                                                                                    if (data->PlayerName[0] == '\0') strcpy(data->PlayerName, "Enemy");
                                                                                }
                                                                                
                                                                                auto GetW2S = [&](uintptr_t nodeOffset) {
                                                                                     uintptr_t nodePtr = Read<uintptr_t>(enemyList + nodeOffset);
                                                                                     if (!nodePtr) return Vector2{0, 0};
                                                                                     Vector3 worldPos = GetNodePosition(nodePtr);
                                                                                     Vector2 screenPos;
                                                                                     if (!WorldToScreen(matrix, worldPos, &screenPos)) return Vector2{0, 0};  
                                                                                     return screenPos;
                                                                                };

                                                                                data->Head = LocationHeadBox;
                                                                                data->Toe = LocationToeBox;
                                                                                data->Head2 = GetW2S(Player::m_HeadNode());
                                                                                data->Hip2  = GetW2S(Player::m_HipNode());
                                                                                data->Root2 = GetW2S(Player::m_RootNode());
                                                                                data->L_Arm  = GetW2S(Player::m_LeftArmNode());
                                                                                data->R_Arm  = GetW2S(Player::m_RightArmNode());
                                                                                data->L_Fore = GetW2S(Player::m_LeftForeArmNode());
                                                                                data->R_Fore = GetW2S(Player::m_RightForeArmNode());
                                                                                data->L_Hand = GetW2S(Player::m_LeftHandNode());
                                                                                data->R_Hand = GetW2S(Player::m_RightHandNode());
                                                                                data->L_Toe = GetW2S(Player::m_LeftToeNode());
                                                                                data->R_Toe = GetW2S(Player::m_RightToeNode());
                                                                                data->IsCaido = isDieing;
                                                                                data->Distancia = distanceToEnemy;
                                                                                data->Name = isClientBot;
                                                                                data->Health = Health;
                                                                                //data->WeaponID = weaponId;
                                                                                // ---------------------------
                                                                                
                                                                                // === FIND BEST TARGET FOR AIMBOT ===
                                                                                // Crosshair theke head box er distance calculate kora
                                                                                float distToCrosshair = sqrt(pow(LocationHeadBox.X - screenCenterX, 2) + pow(LocationHeadBox.Y - screenCenterY, 2));

                                                                                // Check if enemy is inside FOV and closest to crosshair
                                                                                if (distToCrosshair <= fovRadius && distToCrosshair < closestDistToCrosshair && !isDieing) {
                                                                                    closestDistToCrosshair = distToCrosshair;
                                                                                    bestAimbotTarget = EnemyPosition;
                                                                                    bestEnemyListPtr = enemyList;
                                                                                    foundValidTarget = true;
                                                                                }
                                                                                // ===================================

                                                                                ++SendResponse.PlayerCount;
                                                                                if (SendResponse.PlayerCount == maxplayerCount) break;
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                } // for loop sesh
                                                
                                                g_TargetDir = bestAimbotTarget;
                                                
                                                // === EXECUTE AIMBOT AFTER THE LOOP ===
                                                // Karon amra ekhon crosshair er shob theke kacher target ta peye gechi
                                                if (foundValidTarget) {
                                                    // Firing hole rotation apply kora
                                                    if (pPlayer.aimbot && mIsFiring > 0) {
                                                        float aimHeight = (pPlayer.aimbotType == 0) ? 0.0f : -0.18f;
                                                        Quaternion desiredRot = GetRotationToTheLocation(bestAimbotTarget, aimHeight, CameraPosition);  
                                                        Write<Quaternion>(localPlayer + offset::AimRotation, desiredRot);
                                                    }
                                                }
                                                // =====================================

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

__attribute__ ((visibility ("hidden")))
int main(int argc, char*argv[]){
    if (InitServer() == (0)) {
        if (server.Accept()) {
            target_pid = FindPid("com.dts.freefiremax");
            if (target_pid > 0) {
                mem_fd = my_open_mem(target_pid);
                if (mem_fd <= 0) {
                    return 1;
                }
            } else {
                exit(1);
            }
            
            std::thread(SilentAimThread).detach();
            
            libAddress = get_module_base("libil2cpp.so", "r--p");
            if (libAddress == 0) {
            }

            Request request{};
            while (server.receive((void*)&request) > (0)) {
                Response SendResponse{};
                if (request.Mode == Mode::InitMode) {
                    SendResponse.Success = true;
                } else if (request.Mode == Mode::HackMode) {
                    SendResponse.Success = true;
                } else if (request.Mode == Mode::EspMode) {
                    g_screenWidth = request.ScreenWidth;
                    g_screenHeight = request.ScreenHeight;;
                    CreateDataList(SendResponse);
                    SendResponse.Success = true;
                } else if (request.Mode == 3) {
                    Actived.activar = request.m_IsOn;
                    SendResponse.Success = true;
                } else if(request.Mode == 5){
                    pPlayer.aimbot = request.m_IsOn;
                    SendResponse.Success = true;
                } else if(request.Mode == 6){
                    pPlayer.AimSilent = request.m_IsOn;
                    SendResponse.Success = true;
                } else if(request.Mode == 54){
                    pPlayer.aimbotlock = request.m_IsOn;
                    SendResponse.Success = true;
                } else if(request.Mode == 58){
                    pPlayer.AimFov = (float)request.value;
                    SendResponse.Success = true;
                } else if(request.Mode == 60){
                    pPlayer.aimbotType = request.value;
                    SendResponse.Success = true;
				} else if(request.Mode == 61){
                    pPlayer.ghosthack = request.m_IsOn;
                    SendResponse.Success = true;
                } else if(request.Mode == 62){
                    pPlayer.NoRec = request.m_IsOn;
                    SendResponse.Success = true;
                } else if(request.Mode == 63){
                    pPlayer.NoRel = request.m_IsOn;
                    SendResponse.Success = true;
                }
                server.send((void*)& SendResponse, sizeof(SendResponse));
            }
        }
    }
    return 0;
}
