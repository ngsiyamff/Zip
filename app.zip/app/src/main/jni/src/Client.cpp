#include <pthread.h>
#include <jni.h>
#include <src/Socket/client.h>
#include "src/Includes/obfuscate.h"
#include <sys/stat.h>
#include <src/Widgets/ImportWidgets.h>
#include <src/Includes/http.h>
#include "src/Unity/Vector3.hpp"
#include "src/Unity/Vector2.hpp"
#include "src/Unity/Unity.h"
#include "src/Unity/ESP.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "src/Widgets/Methods.h"

#include "Client.h"
#include "BooleanClient.h"
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <strings.h>
#include <cstring>

#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/err.h>
#include <openssl/md5.h>
#include <curl/curl.h>
#include <cstring>
#include <strings.h>
#include "src/Includes/json.h" 
using json = nlohmann::json;
//#include "src/Unity/WeaponIcons.h"

std::string XOR_decryption(std::string value, std::string key) {
    std::string text = "";
    int klen = key.length();
    for (int v = 0; v < value.length(); v++) {
        text += value[v] ^ key[v % klen];
    }
    return text;
}

std::string get_Key_From_Public(std::string publicKey) {
    if (publicKey.length() < 98) return "000000000";
    std::string keyDes = "";
    keyDes += publicKey[58 - 1];
    keyDes += publicKey[62 - 1];
    keyDes += publicKey[10 - 1];
    keyDes += publicKey[47 - 1];
    keyDes += publicKey[20 - 1];
    keyDes += publicKey[33 - 1];
    keyDes += publicKey[87 - 1];
    keyDes += publicKey[98 - 1];
    keyDes += publicKey[14 - 1];
    return keyDes;
}

#define game_package OBFUSCATE("com.dts.freefiremax")
#define LibBypass OBFUSCATE("libanogs.so")

struct {
    bool connectClient = false;
    std::string server_msg = "Waiting..."; 
} Connection;

void KillApp() {
    kill(getpid(), SIGKILL);
    _exit(1);
}

// ===== APK SIGNATURE PROTECTION =====
// Replace with the same SHA-256 value used in SignatureCheck.java.
// Uppercase hex, no colon/spaces.
static const char* EXPECTED_SIGNATURE_SHA256 = "E72F411FCFC41642DDBF8AAC37D4022CBF836AF79E04FC174C222F4D62D68594";
static bool g_signatureOk = true;

static std::string JStringToStd(JNIEnv* env, jstring value) {
    if (!value) return "";
    const char* chars = env->GetStringUTFChars(value, nullptr);
    std::string out = chars ? chars : "";
    if (chars) env->ReleaseStringUTFChars(value, chars);
    return out;
}

static bool IsApkSignatureValid(JNIEnv* env, jobject context) {
    if (!env || !context) return false;

    // Keep debug/build usable until you paste your final release certificate hash.
    if (strncmp(EXPECTED_SIGNATURE_SHA256, "PUT_YOUR_", 9) == 0) return true;

    jclass sigClass = env->FindClass("com/chat/SignatureCheck");
    if (!sigClass) return false;

    jmethodID getHash = env->GetStaticMethodID(
            sigClass,
            "getSignatureSha256",
            "(Landroid/content/Context;)Ljava/lang/String;"
    );
    if (!getHash) {
        env->DeleteLocalRef(sigClass);
        return false;
    }

    jstring currentHash = (jstring) env->CallStaticObjectMethod(sigClass, getHash, context);
    std::string current = JStringToStd(env, currentHash);
    if (currentHash) env->DeleteLocalRef(currentHash);
    env->DeleteLocalRef(sigClass);

    return strcasecmp(current.c_str(), EXPECTED_SIGNATURE_SHA256) == 0;
}

static bool DisconnectIfBadSignature(JNIEnv* env, jobject context) {
    g_signatureOk = IsApkSignatureValid(env, context);
    if (!g_signatureOk) {
        stopClient();
        KillApp();
        Connection.connectClient = false;
        return true;
    }
    return false;
}
// ===== END APK SIGNATURE PROTECTION =====
/*
const char *GetWeaponIconBase64(int id) {
    auto it = WeaponIcons::Icons.find(id);
    if (it == WeaponIcons::Icons.end()) return nullptr;
    return it->second.c_str();
}*/

ESP espOverlay;

void DrawAimLine(ESP esp, const Response& response) {
    if (!pEspPlayer.espTarget) return;
    
    float centerX = esp.getWidth() / 2.0f;
    float centerY = esp.getHeight() / 2.0f;
    float fovRadius = (pPlayer.AimFov / 360.0f) * (esp.getHeight() / 2.0f);
    
    int bestIndex = -1;
    float bestScreenDist = FLT_MAX;
    Vector2 bestHeadScreen;
    
    for (int i = 0; i < response.PlayerCount; i++) {
        const auto& player = response.Players[i];
        if (player.IsCaido) continue;  
        if (player.Head == Vector3::Zero()) continue;
        
        float distToCrosshair = sqrtf(pow(player.Head.X - centerX, 2) + pow(player.Head.Y - centerY, 2));
      
        if (distToCrosshair < fovRadius && distToCrosshair < bestScreenDist) {
            bestScreenDist = distToCrosshair;
            bestIndex = i;
            bestHeadScreen = Vector2(player.Head.X, player.Head.Y);
        }
    }
    
    if (bestIndex != -1) {
        Vector2 start(centerX, centerY);
        esp.DrawLine(pEspPlayer.espColor, 2.5f, start, bestHeadScreen);
    }
}

void DrawESP(ESP esp) {
    if (!isConnected()) return;

    auto screenHeight = esp.getHeight();
    auto screenWidth = esp.getWidth();
    auto response = getData(screenWidth, screenHeight); 
    float playerCount = response.PlayerCount;
    Vector2 fovCenter = { screenWidth / 2.0f, screenHeight / 2.0f };
    float fovRadius = (pPlayer.AimFov / 360.0f) * (screenHeight / 2.0f);
    
    
    if (Actived.activar) {
        DrawAimLine(esp, response);
        esp.DrawCircle(Color(255, 0, 0, 150), 1.0f, fovCenter, fovRadius);
    }
    
    if (Actived.activar && pEspPlayer.espCount) {
        std::string countText = std::to_string((int)playerCount);
        // Fixed size instead of scaling with pEspPlayer.textSize
        float playerCountSize = 40.0f; // Fixed size
        esp.DrawText(pEspPlayer.espColor, countText.c_str(), 
                    Vector2(screenWidth / 2, 100), playerCountSize);
    }
    
    if (!response.Success || response.PlayerCount <= 0) return;
    
    for (int i = 0; i < response.PlayerCount; i++) {
        auto player = response.Players[i];
        if (player.Head.X <= 0 || player.Toe.Y <= 0) continue;
        float h = std::abs(player.Toe.Y - player.Head.Y) * 1.15f; 
        if(h < 10) h = std::abs(player.Toe.Y - player.Head.Y) * 2.2f;
        float w = h * 0.5f;
        float x = player.Head.X - (w / 2);
        float y = player.Head.Y - (h * 0.13f);
        
        Color espCol = player.IsCaido ? Color::Red() : pEspPlayer.espColor;
        if (pEspPlayer.espHealth || pEspPlayer.espName) {
            float healthPc = std::clamp(player.Health / 200.0f, 0.0f, 1.0f);
            
            float barWidth = w;
            if (barWidth < 65.0f) barWidth = 65.0f; 

            float barHeight = 16.0f;
            float barX = player.Head.X - (barWidth / 2.0f); 
            float barY = y - barHeight - 7.0f;
            esp.DrawFilledRect(Color(10, 10, 10, 255), Vector3(barX, barY, 0), barWidth, barHeight);
            Color healthCol = Color(255 * (1.0f - healthPc), 255 * healthPc, 0, 255);
            if (healthPc > 0.8f) healthCol = Color(46, 204, 113, 255); // Green Emerald
            
            float currentHealthWidth = barWidth * healthPc;
            esp.DrawFilledRect(healthCol, Vector3(barX, barY, 0), currentHealthWidth, barHeight);
            esp.DrawFilledRect(Color(0, 0, 0, 80), Vector3(barX, barY + (barHeight / 2.0f), 0), currentHealthWidth, barHeight / 2.0f);
            esp.DrawFilledRect(Color(255, 255, 255, 35), Vector3(barX, barY, 0), currentHealthWidth, barHeight / 4.0f);
            esp.DrawBox(Color(0, 0, 0, 255), 1.0f, Rect(barX, barY, barWidth, barHeight));
            if (pEspPlayer.espName) {
                std::string nameText = player.PlayerName;
                float textScale = pEspPlayer.textSize * 0.82f; 
                float namePosY = barY + (barHeight / 2.0f) + 4.5f; 
                esp.DrawText(Color(0, 0, 0, 255), nameText.c_str(), Vector2(player.Head.X + 1, namePosY + 1), textScale);
                esp.DrawText(Color::White(), nameText.c_str(), Vector2(player.Head.X, namePosY), textScale);
            }
        }
        if (pEspPlayer.espSkeleton && !player.IsCaido) {
            auto Bone = [&](Vector2 from, Vector2 to) {
                if (from.X > 5 && to.X > 5) esp.DrawLine(espCol, 1.3f, from, to);
            };
            Bone(player.Head2, player.Hip2);
            Bone(player.Hip2, player.L_Toe);
            Bone(player.Hip2, player.R_Toe);
            Bone(player.Head2, player.L_Arm);
            Bone(player.Head2, player.R_Arm);
            Bone(player.L_Arm, player.L_Fore);
            Bone(player.L_Fore, player.L_Hand);
            Bone(player.R_Arm, player.R_Fore);
            Bone(player.R_Fore, player.R_Hand);
        }
        if (pEspPlayer.espCaixa) {
            if (pEspPlayer.boxType == 1) { 
                Color fill = espCol; fill.a = 40; 
                esp.DrawFilledRect(fill, Vector3(x, y, 0), w, h);
            }
            
            if (pEspPlayer.boxType == 2) 
                esp.DrawBox4Line(x, y, w, h, espCol, 1.2f);
            else 
                esp.DrawBox(espCol, 1.2f, Rect(x, y, w, h));
        }
        if (pEspPlayer.espLinha) {
            Vector2 start = (pEspPlayer.lineType == 1) ? Vector2(screenWidth/2, screenHeight/2)  : 
                            (pEspPlayer.lineType == 2) ? Vector2(screenWidth/2, screenHeight) : 
                            Vector2(screenWidth / 2.0f, 0.0f);
            esp.DrawLine(espCol, 1.0f, start, Vector2(player.Head.X, y));
        }
        if (pEspPlayer.espDistance) {
            std::string d = std::to_string((int)player.Distancia) + "M";
            esp.DrawText(Color::White(), d.c_str(), Vector2(player.Head.X, y + h + 8), pEspPlayer.textSize * 0.85f);
        }/*
        if (pEspPlayer.espWeapon && player.WeaponID > 0) {
            const char *icon = GetWeaponIconBase64(player.WeaponID);
            
            if (icon) {
                esp.DrawWeaponIcon(player.WeaponID, icon, Vector2(x + (w / 2.0f) - (44.0f / 2.0f), y + h + (pEspPlayer.espDistance ? 28.0f : 8.0f)), 54.0f, 35.0f);
            }
        }*/
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_chat_Floater_Functions(JNIEnv *env, jclass clazz) {
    Widget widget = Widget(env);
    widget.Category(OBFUSCATE("Aim Menu"));
    widget.Switch(OBFUSCATE("Enable Functions"), 1);
	widget.Switch(OBFUSCATE("Aim bot"), 2);
    widget.Switch(OBFUSCATE("Aimbot External"), 6);
    widget.Switch(OBFUSCATE("Aim Silent"), 7);
    widget.SeekBar(OBFUSCATE("Aim Fov"), 99, 360, OBFUSCATE(""), 9);
	widget.SeekBar(OBFUSCATE("Aimbot Type"), 0, 1, OBFUSCATE("AimType"), 28);
    
    widget.Category(OBFUSCATE("Memory Menu"));
    widget.Switch(OBFUSCATE("No Recoil"), 98);
    widget.Switch(OBFUSCATE("No Reload"), 97);
    widget.Switch(OBFUSCATE("Ghost Hack"), 10);
    
    widget.Category(OBFUSCATE("Esp Menu"));
    widget.Switch(OBFUSCATE("Draw Line"), 11);
    widget.Switch(OBFUSCATE("Draw Box"), 12);
    widget.Switch(OBFUSCATE("Draw Target"), 24);
    widget.Switch(OBFUSCATE("Draw Distance"), 13);
    widget.Switch(OBFUSCATE("Draw Skeleton"), 14);
    widget.Switch(OBFUSCATE("Draw Name"), 21);
    //widget.Switch(OBFUSCATE("Draw Weapon"), 22);
    widget.Switch(OBFUSCATE("Draw Health"), 19);
    widget.Switch(OBFUSCATE("Draw Count"), 23);
    
    widget.Category(OBFUSCATE("Esp Config"));
    widget.SeekBar(OBFUSCATE("ESP Color"), 0, 9, OBFUSCATE("Color"), 16);
    widget.SeekBar(OBFUSCATE("Box Type"), 0, 3, OBFUSCATE("BoxType"), 17);
    widget.SeekBar(OBFUSCATE("Line Type"), 0, 2, OBFUSCATE("LineType"), 18);
    widget.SeekBar(OBFUSCATE("Text Size"), 10, 15, OBFUSCATE(""), 20);
    widget.Switch(OBFUSCATE("Hide Record"), 99);
}


extern "C"
JNIEXPORT void JNICALL
Java_com_chat_Floater_ChangesID(JNIEnv *env, jclass clazz, jint id, jint value) {
    if (!g_signatureOk) {
        stopClient();
        Connection.connectClient = false;
        return;
    }
    switch (id) {
        case 1: Actived.activar = !Actived.activar; SendBool(3, Actived.activar); break;
        case 2: pPlayer.aimbot = !pPlayer.aimbot; SendBool(5, pPlayer.aimbot); break;
        case 6: pPlayer.aimbotlock = !pPlayer.aimbotlock; SendBool(54, pPlayer.aimbotlock); break;
        case 7: pPlayer.AimSilent = !pPlayer.AimSilent; SendBool(6, pPlayer.AimSilent); break;
        case 9: pPlayer.AimFov = value; SendFloat(58, pPlayer.AimFov); break;
        case 10: pPlayer.ghosthack = !pPlayer.ghosthack; SendBool(61, pPlayer.ghosthack); break;
        case 11: pEspPlayer.espLinha = !pEspPlayer.espLinha; break;
        case 12: pEspPlayer.espCaixa = !pEspPlayer.espCaixa; break;
        case 13: pEspPlayer.espDistance = !pEspPlayer.espDistance; break;
        case 14: pEspPlayer.espSkeleton = !pEspPlayer.espSkeleton; break;
        case 15: pEspPlayer.espIden360 = !pEspPlayer.espIden360; break;
        case 16:
            if (value == 0) pEspPlayer.espColor = Color(255, 255, 255, 255);
            else if (value == 1) pEspPlayer.espColor = Color(0, 255, 0, 255);
            else if (value == 2) pEspPlayer.espColor = Color(0, 0, 255, 255);
            else if (value == 3) pEspPlayer.espColor = Color(255, 0, 0, 255);
            else if (value == 4) pEspPlayer.espColor = Color(0, 0, 0, 255);
            else if (value == 5) pEspPlayer.espColor = Color(255, 255, 0, 255);
            else if (value == 6) pEspPlayer.espColor = Color(0, 255, 255, 255);
            else if (value == 7) pEspPlayer.espColor = Color(255, 0, 255, 255);
            else if (value == 8) pEspPlayer.espColor = Color(128, 128, 128, 255);
            else if (value == 9) pEspPlayer.espColor = Color(160, 32, 240, 255);
        break;
        case 17: pEspPlayer.boxType = static_cast<BoxType>(value); break;
        case 18: pEspPlayer.lineType = static_cast<LineType>(value); break;
        case 19: pEspPlayer.espHealth = !pEspPlayer.espHealth; break;
        case 20: pEspPlayer.textSize = (float)value; break;
        case 21: pEspPlayer.espName = !pEspPlayer.espName; break;
       // case 22: pEspPlayer.espWeapon = !pEspPlayer.espWeapon; break;
        case 23: pEspPlayer.espCount = !pEspPlayer.espCount; break;
        case 24: pEspPlayer.espTarget = !pEspPlayer.espTarget; break;
        case 28: pPlayer.aimbotType = static_cast<AimType>(value); SendInt(60, pPlayer.aimbotType); break;    
        case 98: pPlayer.NoRec = !pPlayer.NoRec; SendBool(62, pPlayer.NoRec); break;
        case 97: pPlayer.NoRel = !pPlayer.NoRel; SendBool(63, pPlayer.NoRel); break;
    }
}


extern "C" JNIEXPORT void JNICALL
Java_com_chat_Floater_PxbftKZXivSr(JNIEnv *env, jclass type, jobject espView, jobject canvas, jint width, jint height) {
    ESP localEsp = ESP(env, espView, canvas);
    if (localEsp.isValid()) { DrawESP(localEsp); }
}

extern "C" JNIEXPORT void JNICALL
Java_com_chat_Floater_ftKZXivSr(JNIEnv *env, jclass clazz, jobject ctx) {
    if (DisconnectIfBadSignature(env, ctx)) {
        Toast(env, ctx, "Signature changed! Socket disconnected.", 1, 1);
        return;
    }

    if (!Connection.connectClient) {
        startClient();
        Connection.connectClient = true;
        Toast(env, ctx, "ACTIVATING...", 1, 1);
        Toast(env, ctx, "ACTIVATED", 1, 1);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_chat_Floater_ftKwCvSr(JNIEnv *env, jclass clazz) {
    stopClient();
}

extern "C"
JNIEXPORT void JNICALL
Java_com_chat_Auth_stopSocket(JNIEnv *env, jobject thiz) {
    stopClient();
    Connection.connectClient = false;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_chat_LoginActivity_updateUrl(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF("https://rewardff.com.br/update.php");
}

bool bValid = false, lolo = false;
std::string g_Token, g_Auth;

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass("android/content/Context");
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass,"getContentResolver","()Landroid/content/ContentResolver;");
    jclass settingSecureClass = env->FindClass("android/provider/Settings$Secure");
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass,"getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj,env->NewStringUTF("android_id"));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass("android/os/Build");
    jfieldID modelId = env->GetStaticFieldID(buildClass, "MODEL","Ljava/lang/String;");

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass("android/os/Build");
    jfieldID modelId = env->GetStaticFieldID(buildClass, "BRAND","Ljava/lang/String;");

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass("android/content/Context");
    jmethodID getPackageNameId = env->GetMethodID(contextClass, "getPackageName","()Ljava/lang/String;");

    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass("java/util/UUID");

    auto len = strlen(uuid);

    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);

    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass,"nameUUIDFromBytes","([B)Ljava/util/UUID;");
    jmethodID toStringMethod = env->GetMethodID(uuidClass, "toString","()Ljava/lang/String;");

    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    struct MemoryStruct *mem = (struct MemoryStruct *) userp;

    mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == NULL) {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

std::string CalcMD5(std::string s) {
    std::string result;

    unsigned char hash[MD5_DIGEST_LENGTH];
    char tmp[4];

    MD5_CTX md5;
    MD5_Init(&md5);
    MD5_Update(&md5, s.c_str(), s.length());
    MD5_Final(hash, &md5);
    for (unsigned char i : hash) {
        sprintf(tmp, "%02x", i);
        result += tmp;
    }
    return result;
}

std::string CalcSHA256(std::string s) {
    std::string result;

    unsigned char hash[SHA256_DIGEST_LENGTH];
    char tmp[4];

    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, s.c_str(), s.length());
    SHA256_Final(hash, &sha256);
    for (unsigned char i : hash) {
        sprintf(tmp, "%02x", i);
        result += tmp;
    }
    return result;
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_chat_Auth_nativeLogin(JNIEnv *env, jobject thiz, jstring uKey, jstring uHwid) {
    const char *key = env->GetStringUTFChars(uKey, 0);
    const char *hwid = env->GetStringUTFChars(uHwid, 0);
    std::string deviceModel = GetDeviceModel(env);

    CURL *curl;
    struct MemoryStruct chunk{};
    chunk.memory = (char *)malloc(1);
    chunk.size = 0;

    curl = curl_easy_init();
    if (curl) {
        // --- FIX 1: URL KO SAHI KIYA ---
        curl_easy_setopt(curl, CURLOPT_URL, "http://external.onlinewebshop.net/connect.php");

        // --- FIX 2: FORM DATA FORMAT (POST) ---
        // Apka PHP code $this->request->getPost() use kar raha hai, isliye hum string format mein bhejenge
         std::string postData = "app=FreeFire&user_key=" + std::string(key) + "&serial=" + std::string(hwid) + "&model=" + std::string(deviceModel);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *)&chunk);
        
        // SSL and Timeout settings
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);

        if (curl_easy_perform(curl) == CURLE_OK) {
            try {
                // PHP se JSON response decode karna
                json response = json::parse(chunk.memory);

                // --- FIX 3: SIMPLE STATUS CHECK ---
                // Kyunki Connect.php mein XOR encryption nahi hai, hum direct status check karenge
                if (response["status"] == true) {
                    // Agar login success hai, toh 'reason' ya 'message' return karein
                    // Aapke PHP mein data['status'] true hone par 'data' array bhej raha hai
                    Connection.server_msg = "Login Success"; 
                } else {
                    // Agar status false hai, toh 'reason' bhejega (e.g., "USER BLOCKED")
                    std::string reason = response["reason"];
                    Connection.server_msg = reason;
                }
            } catch (...) {
                Connection.server_msg = "Parser Error or Invalid Key";
            }
        } else {
            Connection.server_msg = "Server Connect Error";
        }
        curl_easy_cleanup(curl);
    }
    free(chunk.memory);
    env->ReleaseStringUTFChars(uKey, key);
    env->ReleaseStringUTFChars(uHwid, hwid);
    return env->NewStringUTF(Connection.server_msg.c_str());
}

// ================================================
// আপনার existing .cpp file এ এই দুটো function যোগ করুন
// ================================================

// App version auto-detect করবে
static std::string GetAppVersion(JNIEnv *env, jobject context) {
    try {
        jclass ctxClass = env->FindClass("android/content/Context");
        jmethodID getPM = env->GetMethodID(ctxClass, "getPackageManager", "()Landroid/content/pm/PackageManager;");
        jmethodID getPkg = env->GetMethodID(ctxClass, "getPackageName", "()Ljava/lang/String;");
        jobject pm = env->CallObjectMethod(context, getPM);
        jstring pkgName = (jstring) env->CallObjectMethod(context, getPkg);
        jclass pmClass = env->FindClass("android/content/pm/PackageManager");
        jmethodID getPkgInfo = env->GetMethodID(pmClass, "getPackageInfo", "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
        jobject pkgInfo = env->CallObjectMethod(pm, getPkgInfo, pkgName, 0);
        jclass piClass = env->FindClass("android/content/pm/PackageInfo");
        jfieldID verNameField = env->GetFieldID(piClass, "versionName", "Ljava/lang/String;");
        jstring verName = (jstring) env->GetObjectField(pkgInfo, verNameField);
        const char *v = env->GetStringUTFChars(verName, 0);
        std::string result(v);
        env->ReleaseStringUTFChars(verName, v);
        return result;
    } catch (...) {
        return "1.0.0";
    }
}

// check.php call করবে — app open হলে call করুন
// Returns: "TYPE|TITLE|MESSAGE|VERSION|URL"
extern "C"
JNIEXPORT jstring JNICALL
Java_com_chat_LoginActivity_nativeCheckUpdate(JNIEnv *env, jobject thiz, jobject context) {

    std::string appVersion = GetAppVersion(env, context);
    std::string result = "none||||";

    CURL *curl;
    struct MemoryStruct chunk{};
    chunk.memory = (char *) malloc(1);
    chunk.size = 0;

    curl = curl_easy_init();
    if (curl) {
        std::string postData =
            "app=FreeFire"
            "&app_version=" + appVersion;

        curl_easy_setopt(curl, CURLOPT_URL, "https://external.onlinewebshop.net/check.php");
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long) postData.size());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);

        if (curl_easy_perform(curl) == CURLE_OK) {
            try {
                json resp = json::parse(chunk.memory);
                std::string type = resp.value("type",           "none");
                std::string titl = resp.value("title",          "");
                std::string msg  = resp.value("message",        "");
                std::string ver  = resp.value("update_version", "");
                std::string url  = resp.value("update_url",     "");
                result = type+"|"+titl+"|"+msg+"|"+ver+"|"+url;
            } catch (...) {
                result = "none||||";
            }
        }
        curl_easy_cleanup(curl);
    }
    free(chunk.memory);
    return env->NewStringUTF(result.c_str());
}


// Add the missing showNativeAlertDialog function
extern "C" JNIEXPORT void JNICALL
Java_com_chat_MainActivity_showNativeAlertDialog(JNIEnv* env, jobject thiz) {
    // Show a toast instead of a dialog
    jclass toastClass = env->FindClass("android/widget/Toast");
    if (toastClass == nullptr) return;
    
    jmethodID makeText = env->GetStaticMethodID(toastClass, "makeText", 
        "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
    if (makeText == nullptr) return;
    
    jmethodID show = env->GetMethodID(toastClass, "show", "()V");
    if (show == nullptr) return;
    
    jstring message = env->NewStringUTF("Native Library Loaded!");
    
    jobject toast = env->CallStaticObjectMethod(toastClass, makeText, thiz, message, 0);
    if (toast != nullptr) {
        env->CallVoidMethod(toast, show);
    }
    
    env->DeleteLocalRef(message);
}

extern "C" JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM* vm, void* reserved) {
    return JNI_VERSION_1_6;
}