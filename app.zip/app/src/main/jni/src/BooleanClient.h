// Define enum types first
enum BoxType {
    BOX_STROKE = 0,
    BOX_FILLED = 1,
    BOX_CORNER = 2,
    BOX_ROUNDED = 3
};

enum LineType {
    LINE_TOP = 0,
    LINE_CENTER = 1,
    LINE_BOTTOM = 2
};

enum AimType {
    HEAD = 0,
    BODY = 1
};

struct {
    bool aimbot = false;
    bool AimSilent = false;
    float AimFov = 99;
    bool aimbotlock = false;
	AimType aimbotType = HEAD;
    bool ghosthack = false;
    bool NoRec = false;
    bool NoRel = false;
} pPlayer;

struct {
    bool Bypass = false;
    bool activar = false;
} Actived;

struct {
    bool espLinha = false;
    bool espTarget = false;
    bool espCount = false;
    bool espCaixa = false;
    bool espHealth = false;    // Renamed from espInfo for clarity
    bool espDistance = false;  // Renamed from espDistancia
    bool espName = false;
    bool espSkeleton = false;
    bool espIden360 = false;
    bool espWeapon = false;
    float textSize = 15.0f;    // Changed to float for smooth scaling
    Color espColor = Color::White();
    BoxType boxType = BOX_STROKE;
    LineType lineType = LINE_TOP;
} pEspPlayer;

