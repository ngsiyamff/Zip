
struct {
    bool aimbot = false;
    bool AimSilent = false;
    float AimFov = 99;
    bool aimbotlock = false;
	int aimbotType = 0;
    bool ghosthack = false;
    bool NoRec = false;
    bool NoRel = false;
} pPlayer;

struct {
    bool activar = false;
} Actived;
