#include <jni.h>
#include <stdio.h>
#include <wchar.h>
#include "Includes/Logger.h"
#include "src/Unity/Quaternion.hpp"
#include "src/Unity/Vector3.hpp"

#include <src/Socket/server.h>
#include "src/Unity/Unity.h"
#include "src/Unity/Color.hpp"
#include "src/Unity/Rect.hpp"
#include "src/Unity/ESP.h"

#include <stdint.h>
#include "Includes/Utils.h"
#include "Includes/offset.h"
#include "BooleanServer.h"
#include <thread>
#include <chrono>

SocketServer server;

int g_screenWidth, g_screenHeight;

#define maxplayerCount 200

enum Mode {
    InitMode = 1,
    HackMode = 2,
    StopMode = 98,
    EspMode = 99,
};

struct Request {
    int Mode;
    bool m_IsOn;
    int value;
    int ScreenWidth;
    int ScreenHeight;
};

struct PlayerData {
    Vector3 Head;
    Vector3 Toe;
    Vector2 Head2, Hip2, Root2;
    Vector2 L_Arm, R_Arm, L_Fore, R_Fore, L_Hand, R_Hand;
    Vector2 L_Toe, R_Toe;
    bool IsCaido;
    float Distancia;
    int Health;
    bool Name;
    char PlayerName[64];
    int WeaponID;
};

namespace Player {
    // Fungsi pembantu agar tidak ngetik ulang
    inline uintptr_t cam() { return offset::FollowCamera; }

    inline uintptr_t m_HeadNode() { return cam() + 0x10; }
    inline uintptr_t m_HipNode() { return cam() + 0x18; }
    inline uintptr_t m_RootNode() { return cam() + 0x38; } 
    inline uintptr_t m_LeftToeNode() { return cam() + 0x58; }
    inline uintptr_t m_RightToeNode() { return cam() + 0x60; }
    inline uintptr_t m_LeftArmNode() { return cam() + 0x78; }
    inline uintptr_t m_RightArmNode() { return cam() + 0x80; }
    inline uintptr_t m_LeftForeArmNode() { return cam() + 0xA0; }
    inline uintptr_t m_RightForeArmNode() { return cam() + 0x98; }
    inline uintptr_t m_LeftHandNode() { return cam() + 0x90; }
    inline uintptr_t m_RightHandNode() { return cam() + 0x88; }
}

struct Response {
    bool Success;
    int PlayerCount;
    PlayerData Players[maxplayerCount];
};

int InitServer() {
    if (!server.Create()) {
        LOGE("[Server] Socket can't connect");
        return -1;
    }
    if (!server.Bind()) {
        LOGE("[Server] Socket can't connect");
        return -1;
    }
    if (!server.Listen()) {
        LOGE("[Server] Socket can't connect");
        return -1;
    }
    LOGI("[Server] Socket connected");
    return 0;
}

uintptr_t GetPlayerHeadTF(uintptr_t player) {
    auto ptr = Read<uintptr_t>(player + bone::Head);
    return ptr;
}

uintptr_t GetPlayerPeTF(uintptr_t player) {
    auto ptr = Read<uintptr_t>(player + bone::Root);
    return ptr;
}

uintptr_t GetPlayerMainCamera(uintptr_t player) {
    auto ptr = Read<uintptr_t>(player + offset::MainCameraTransform);
    return ptr;
}

struct Matrix {
    Vector4 Position;
    Quaternion Rotation;
    Vector4 Scale;
};

static auto GetPosition(uintptr_t Transform) {
    auto pos = Vector3::Zero();

    auto transformObjValue = Read<uintptr_t>(Transform + offset::transformObjValue);
    if (transformObjValue == 0) {
        return pos;
    }

    auto indexValue = Read<uintptr_t>(transformObjValue + offset::indexValue);
    auto matrixValue = Read<uintptr_t>(transformObjValue + offset::matrixValue);

    auto matrixListValue = Read<uintptr_t>(matrixValue + offset::matrixListValue);
    auto matrixIndicesValue = Read<uintptr_t>(matrixValue + offset::matrixIndicesValue);

    auto resultValue = Read<Vector3>(matrixListValue + (indexValue * offset::resultValue)); // FIXED: 64-bit pointer arithmetic

    auto maxTries = 50;
    auto tries = 0;

    // FIXED: Proper 64-bit pointer arithmetic
    auto transformIndexValue = Read<int>(matrixIndicesValue + (indexValue * 4));

    while (transformIndexValue >= 0 && tries < maxTries) {
        tries++;

        // FIXED: Proper 64-bit pointer arithmetic
        auto tMatrixValue = Read<Matrix>(matrixListValue + (transformIndexValue * offset::tMatrixValue));

        auto rotX = tMatrixValue.Rotation.X;
        auto rotY = tMatrixValue.Rotation.Y;
        auto rotZ = tMatrixValue.Rotation.Z;
        auto rotW = tMatrixValue.Rotation.W;

        auto scaleX = resultValue.X * tMatrixValue.Scale.X;
        auto scaleY = resultValue.Y * tMatrixValue.Scale.Y;
        auto scaleZ = resultValue.Z * tMatrixValue.Scale.Z;

        resultValue.X = tMatrixValue.Position.X + scaleX +
                        (scaleX * ((rotY * rotY * -2.0) - (rotZ * rotZ * 2.0))) +
                        (scaleY * ((rotW * rotZ * -2.0) - (rotY * rotX * -2.0))) +
                        (scaleZ * ((rotZ * rotX * 2.0) - (rotW * rotY * -2.0)));
        resultValue.Y = tMatrixValue.Position.Y + scaleY +
                        (scaleX * ((rotX * rotY * 2.0) - (rotW * rotZ * -2.0))) +
                        (scaleY * ((rotZ * rotZ * -2.0) - (rotX * rotX * 2.0))) +
                        (scaleZ * ((rotW * rotX * -2.0) - (rotZ * rotY * -2.0)));
        resultValue.Z = tMatrixValue.Position.Z + scaleZ +
                        (scaleX * ((rotW * rotY * -2.0) - (rotX * rotZ * -2.0))) +
                        (scaleY * ((rotY * rotZ * 2.0) - (rotW * rotX * -2.0))) +
                        (scaleZ * ((rotX * rotX * -2.0) - (rotY * rotY * 2.0)));

        // FIXED: Proper 64-bit pointer arithmetic
        transformIndexValue = Read<int>(matrixIndicesValue + (transformIndexValue * 4));
    }

    if (tries < maxTries) {
        pos = resultValue;
    }

    return pos;
}

static auto GetNodePosition(uintptr_t nodeTransform) {
    auto transformValue = Read<uintptr_t>(nodeTransform + offset::transformValue);
    if (transformValue == 0) {
        return Vector3::Zero();
    }
    return GetPosition(transformValue);
}

static auto WorldToScreenPoint(D3DMatrix viewMatrix, Vector3 ScreenPos) {
    auto result = Vector3(-1, -1, -1);

    auto v9 = (ScreenPos.X * viewMatrix._11) + (ScreenPos.Y * viewMatrix._21) + (ScreenPos.Z * viewMatrix._31) + viewMatrix._41;
    auto v10 = (ScreenPos.X * viewMatrix._12) + (ScreenPos.Y * viewMatrix._22) + (ScreenPos.Z * viewMatrix._32) + viewMatrix._42;
    auto v12 = (ScreenPos.X * viewMatrix._14) + (ScreenPos.Y * viewMatrix._24) + (ScreenPos.Z * viewMatrix._34) + viewMatrix._44;

    if (v12 >= 0.001f) {
        auto v13 = (float)g_screenWidth / 2.0f;
        auto v14 = (float)g_screenHeight / 2.0f;

        result.X = v13 + (v13 * v9) / v12;
        result.Y = v14 - (v14 * v10) / v12;
    }
    return result;
}

Vector3 GetBonePosition(uintptr_t player, uintptr_t offset) {
    uintptr_t bone = Read<uintptr_t>(player + offset);
    if (!bone) return Vector3::Zero();
    return GetNodePosition(bone);
}

bool WorldToScreen(D3DMatrix mat, const Vector3 &from, Vector2 *to) {
    if (!to) return false;

    Vector3 res;
    float w;

    res.X = mat._11 * from.X + mat._21 * from.Y + mat._31 * from.Z + mat._41;
    res.Y = mat._12 * from.X + mat._22 * from.Y + mat._32 * from.Z + mat._42;
    res.Z = mat._13 * from.X + mat._23 * from.Y + mat._33 * from.Z + mat._43;

    w = mat._14 * from.X + mat._24 * from.Y + mat._34 * from.Z + mat._44;

    if (w > 0.001f) {
        float invW = 1.0f / w;

        res.X *= invW;
        res.Y *= invW;
        res.Z *= invW;

        Vector3 screenPos(
            (res.X + 1.0f) * 0.5f,
            (res.Y + 1.0f) * 0.5f,
            (res.Z + 1.0f) * 0.5f
        );

        to->X = screenPos.X * g_screenWidth;
        to->Y = g_screenHeight - (screenPos.Y * g_screenHeight);

        return true;
    }

    to->X = -1.0f;
    to->Y = -1.0f;
    return false;
}


Quaternion GetRotationToTheLocation(Vector3 Target, float Height, Vector3 MyEnemy) {
    return Quaternion::LookRotation((Target + Vector3(0, Height, 0)) - MyEnemy, Vector3(0, 1, 0));
}

void getUTF8(char* dst, uintptr_t addr) {
    if (addr < 0x10000000) {
        dst[0] = '\0';
        return;
    }

    int stringLen = Read<int>(addr + 0x10);
    if (stringLen <= 0 || stringLen > 64) {
        stringLen = 32; 
    }

    unsigned char raw[128]; 
    for (int i = 0; i < (stringLen * 2); i++) {
        raw[i] = Read<unsigned char>(addr + 0x14 + i);
    }

    int j = 0;
    for (int i = 0; i < (stringLen * 2); i += 2) {
        unsigned short unicode = raw[i] | (raw[i + 1] << 8);
        if (unicode == 0) break;
        if (unicode < 0x80) {
            dst[j++] = (char)unicode;
        } else if (unicode < 0x800) {
            dst[j++] = (char)((unicode >> 6) | 0xC0);
            dst[j++] = (char)((unicode & 0x3F) | 0x80);
        } else if (unicode >= 0xD800 && unicode <= 0xDBFF) { 
            i += 2;
            unsigned short low = raw[i] | (raw[i + 1] << 8);
            unsigned int codepoint = 0x10000 + ((unicode - 0xD800) << 10) + (low - 0xDC00);
            dst[j++] = (char)((codepoint >> 18) | 0xF0);
            dst[j++] = (char)(((codepoint >> 12) & 0x3F) | 0x80);
            dst[j++] = (char)(((codepoint >> 6) & 0x3F) | 0x80);
            dst[j++] = (char)((codepoint & 0x3F) | 0x80);
        } else {
            dst[j++] = (char)((unicode >> 12) | 0xE0);
            dst[j++] = (char)(((unicode >> 6) & 0x3F) | 0x80);
            dst[j++] = (char)((unicode & 0x3F) | 0x80);
        }
        if (j >= 60) break; 
    }
    dst[j] = '\0';
}