#ifndef ESP_H
#define ESP_H

#include <jni.h>
#include <algorithm>  // Added for std::min
#include "Color.hpp"
#include "Rect.hpp"

class ESP {
private:
    JNIEnv *_env;
    jobject _cvsView;
    jobject _cvs;

public:
    ESP() {
        _env = nullptr;
        _cvsView = nullptr;
        _cvs = nullptr;
    }

    ESP(JNIEnv *env, jobject cvsView, jobject cvs) {
        this->_env = env;
        this->_cvsView = cvsView;
        this->_cvs = cvs;
    }

    bool isValid() const {
        return (_env != nullptr && _cvsView != nullptr && _cvs != nullptr);
    }

    int getWidth() const {
        if (isValid()) {
            jclass canvas = _env->GetObjectClass(_cvs);
            jmethodID width = _env->GetMethodID(canvas, ("getWidth"), ("()I"));
            return _env->CallIntMethod(_cvs, width);
        }
        return 0;
    }

    int getHeight() const {
        if (isValid()) {
            jclass canvas = _env->GetObjectClass(_cvs);
            jmethodID width = _env->GetMethodID(canvas, ("getHeight"), ("()I"));
            return _env->CallIntMethod(_cvs, width);
        }
        return 0;
    }

    void DrawLine(Color color, float thickness, Vector2 start, Vector2 end) {
       if (isValid()) {
           jclass canvasView = _env->GetObjectClass(_cvsView);
           static jmethodID mid = _env->GetMethodID(_env->GetObjectClass(_cvsView), "DrawLine", "(Landroid/graphics/Canvas;IIIIFFFFF)V");
           _env->CallVoidMethod(_cvsView, mid, _cvs, (int)color.a, (int)color.r, (int)color.g, (int)color.b, thickness, start.X, start.Y, end.X, end.Y);
       }
    }


    void DrawText(Color color, const char *txt, Vector2 pos, float size) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawtext = _env->GetMethodID(canvasView, ("DrawText"),
                                                   ("(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V"));
            _env->CallVoidMethod(_cvsView, drawtext, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 _env->NewStringUTF(txt), pos.X, pos.Y, size);
        }
    }

    void DrawText2(Color color, float stroke, const char *txt, Vector2 pos, float size) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawtext = _env->GetMethodID(canvasView, ("DrawText"),
                                                   ("(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V"));
            _env->CallVoidMethod(_cvsView, drawtext, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 _env->NewStringUTF(txt), pos.X, pos.Y, size);
        }
    }

    void DrawName(Color color, const char *txt, Vector3 pos, float size) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawtext = _env->GetMethodID(canvasView, ("DrawName"),
                                                   ("(Landroid/graphics/Canvas;IIIILjava/lang/String;IFFF)V"));
            jstring s=_env->NewStringUTF(txt);
            _env->CallVoidMethod(_cvsView, drawtext, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 s, pos.X, pos.Y, size);
            _env->DeleteLocalRef(s);
        }
    }

    void DrawFilledCircle(Color color, Vector2 pos, float radius) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawfilledcircle = _env->GetMethodID(canvasView, ("DrawFilledCircle"),
                                                           ("(Landroid/graphics/Canvas;IIIIFFF)V"));
            _env->CallVoidMethod(_cvsView, drawfilledcircle, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b, pos.X, pos.Y, radius);
        }
    }

    void DrawCircle(Color color, float stroke, Vector2 pos, float radius) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawcircle = _env->GetMethodID(canvasView, ("DrawCircle"),
                                                     ("(Landroid/graphics/Canvas;IIIIFFFF)V"));
            _env->CallVoidMethod(_cvsView, drawcircle, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,stroke, pos.X, pos.Y, radius);
        }
    }

    void DrawFilledRect(Color color, Vector3 pos, float width, float height) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawfilledrect = _env->GetMethodID(canvasView, "DrawFilledRect",
                                                         "(Landroid/graphics/Canvas;IIIIFFFF)V");
            _env->CallVoidMethod(_cvsView, drawfilledrect, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b, pos.X, pos.Y, width, height);
        }
    }

    void DrawFilledRect(Rect rect, Color color) {
        DrawFilledRect(color, Vector3(rect.x, rect.y, 0), rect.width, rect.height);
    }

    void DrawBox(Color color, float stroke, Rect rect) {
    // Gunakan Vector2 karena ini koordinat layar (2D)
         Vector2 v1 = { rect.x, rect.y };                         // Pojok Kiri Atas
         Vector2 v2 = { rect.x + rect.width, rect.y };           // Pojok Kanan Atas
         Vector2 v3 = { rect.x + rect.width, rect.y + rect.height }; // Pojok Kanan Bawah
         Vector2 v4 = { rect.x, rect.y + rect.height };          // Pojok Kiri Bawah

    // Panggil DrawLine yang sudah menggunakan Vector2
         DrawLine(color, stroke, v1, v2); // Garis Atas
         DrawLine(color, stroke, v2, v3); // Garis Kanan
         DrawLine(color, stroke, v3, v4); // Garis Bawah
         DrawLine(color, stroke, v4, v1); // Garis Kiri
    }

    void DrawBox4Line(float x, float y, float width, float height, Color color, float thickness) {
    // Tentukan panjang garis pojok (25% dari lebar/tinggi)
         float lineW = width / 4.0f;
         float lineH = height / 4.0f;

    // --- Pojok Kiri Atas ---
         DrawLine(color, thickness, {x, y}, {x + lineW, y}); // Horizontal
         DrawLine(color, thickness, {x, y}, {x, y + lineH}); // Vertical

    // --- Pojok Kanan Atas ---
         DrawLine(color, thickness, {x + width, y}, {x + width - lineW, y}); // Horizontal
         DrawLine(color, thickness, {x + width, y}, {x + width, y + lineH}); // Vertical

    // --- Pojok Kiri Bawah ---
         DrawLine(color, thickness, {x, y + height}, {x + lineW, y + height}); // Horizontal
         DrawLine(color, thickness, {x, y + height}, {x, y + height - lineH}); // Vertical

    // --- Pojok Kanan Bawah ---
         DrawLine(color, thickness, {x + width, y + height}, {x + width - lineW, y + height}); // Horizontal
         DrawLine(color, thickness, {x + width, y + height}, {x + width, y + height - lineH}); // Vertical
    }

    void DrawVerticalHealthBar(Vector2 screenPos, float height, float maxHealth, float currentHealth, float width = 8.0f, bool showText = false) {
        // Calculate health percentage and bar height
        float healthPercentage = std::min(1.0f, std::max(0.0f, currentHealth / maxHealth));
        float healthHeight = height * healthPercentage;
        
        // Determine color based on health percentage
        Color healthColor;
        if (healthPercentage > 0.6f) {
            healthColor = Color(0, 255, 0, 200);    // Green for high health
        } else if (healthPercentage > 0.3f) {
            healthColor = Color(255, 255, 0, 200);  // Yellow for medium health
        } else {
            healthColor = Color(255, 0, 0, 200);    // Red for low health
        }
        
        // Draw filled health bar (from bottom to top) - NO BORDER
        float healthY = screenPos.Y + (height - healthHeight);
        DrawFilledRect(healthColor, Vector3(screenPos.X, healthY, 0), width, healthHeight);
        
        // Optional: Draw health text next to the bar (only if showText is true)
        if (showText && height > 30) {
            char healthText[16];
            snprintf(healthText, sizeof(healthText), "%.0f", currentHealth);
            
            // Position text to the left of the health bar
            DrawText(Color(255, 255, 255, 200), 
                    healthText, 
                    Vector2(screenPos.X - 25, screenPos.Y + (height / 2) - 6), 
                    10.0f);
        }
    }

    void DrawHorizontalHealthBar(Vector2 screenPos, float width, float maxHealth, float currentHealth) {
        screenPos -= Vector2(0.0f, 5.0f);
        DrawBox(Color(0, 0, 0, 255), 1, Rect(screenPos.X, screenPos.Y, width, 5.0f));
        screenPos += Vector2(1.0f, 1.0f);
        Color clr = Color(0, 255, 0, 255);
        float hpWidth = (currentHealth * (width - 2)) / maxHealth;

        hpWidth = std::min(hpWidth, width);

        if (currentHealth <= (maxHealth * 0.6)) {
            clr = Color(255, 255, 0, 255);
        }
        if (currentHealth < (maxHealth * 0.4)) {
            clr = Color(255, 0, 0, 255);
        }
        DrawBox(clr, 1, Rect(screenPos.X, screenPos.Y, hpWidth, 4.0f));
    }

    // Helper method to create alpha-blended color - FIXED VERSION
    Color AlphaBlend(Color base, Color overlay) {
        float alpha = overlay.a / 255.0f;
        float invAlpha = 1.0f - alpha;
        
        int r = (int)(base.r * invAlpha + overlay.r * alpha);
        int g = (int)(base.g * invAlpha + overlay.g * alpha);
        int b = (int)(base.b * invAlpha + overlay.b * alpha);
        int a = (int)(base.a + overlay.a);
        
        // Clamp values between 0-255
        r = r < 0 ? 0 : (r > 255 ? 255 : r);
        g = g < 0 ? 0 : (g > 255 ? 255 : g);
        b = b < 0 ? 0 : (b > 255 ? 255 : b);
        a = a < 0 ? 0 : (a > 255 ? 255 : a);
        
        return Color(r, g, b, a);
    }
    
    void DrawWeaponIcon(int weaponId, const char *base64, Vector2 pos, float w, float h) {
        if (!isValid() || base64 == nullptr) return;
        
        jclass cls = _env->GetObjectClass(_cvsView);
        
        static jmethodID mid = _env->GetMethodID(cls,
            "DrawWeaponIcon",
            "(Landroid/graphics/Canvas;ILjava/lang/String;FFFF)V"
        );
        
        if (!mid) return;
        
        jstring jBase64 = _env->NewStringUTF(base64);
        
        _env->CallVoidMethod(_cvsView, mid, _cvs, weaponId, jBase64, pos.X, pos.Y, w, h);
        
        _env->DeleteLocalRef(jBase64);
    }
};

#endif
