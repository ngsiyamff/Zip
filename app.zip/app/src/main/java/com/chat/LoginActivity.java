package com.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.io.IOException;

public class LoginActivity {

    static {
        System.loadLibrary("FUCKGARENA");
    }
    
    public native String nativeCheckUpdate(Object context);

    // =========================
    // FULLSCREEN VIDEOVIEW
    // =========================
    public static class FullScreenVideoView extends VideoView {
        public FullScreenVideoView(Context context) {
            super(context);
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int width = MeasureSpec.getSize(widthMeasureSpec);
            int height = MeasureSpec.getSize(heightMeasureSpec);
            setMeasuredDimension(width, height);
        }
    }

    private static final String USER_ICON_BASE64 =
            "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABTUlEQVRIS73UISxFcRTH8Y8oSUZgYyNJxmY2KhNEGpEmkT2ZpBFpRMGobGZjksTGRmCSJLK/vWvP8+7//nE58e6c8/2f3/md2yQt5jCC0Wr6EY6xWVTeVJSAMwzk5J1jMNajCLCDqYJH7GI6LycGmMFWwoQhZRbbjXJjgJTXZz1zp4gB7tCROME9Or87wQ26EgG36P4uIOgf9pASQf+why8Rkyh4fyOlO+bzbqLIprEbyNjRWygChCYxN0VvIBSnAEJe2MUkhqvPPsFenvdrZU0FJK4ifcmt6EM/WrCP07ryIUzgGRe4xFM9otEEwTnBQfXxgqvqx140N8gJf9fgqI+oB7z+WIvPhR99awGLWC0JsIS1Whe14aGk5lmbdjxmE4zhoGTAOA4zQJnyZO98lykDVLBc8gQrqPwb4M+XHNQJV7mOnl9KdY2F6vV7A9ESNhl4JmGYAAAAAElFTkSuQmCC";

    private static FrameLayout container;
    private static Button loginButton;
    private static ProgressDialog progressDialog;
    private static Context appContext;
    private static FullScreenVideoView bgVideo;

    private EditText etUser;

    private SharedPreferences sharedPreferences;
    private String data_username;
    private final ExecutorService exec   = Executors.newSingleThreadExecutor();
    private final Handler        ui     = new Handler(Looper.getMainLooper());

    // =========================
    // CONSTRUCTOR
    // =========================
    public LoginActivity(final Context context) {

        appContext = context;

        ((Activity) context).setRequestedOrientation(
                ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        );
        
        sharedPreferences = context.getSharedPreferences(
                "LoginPrefs",
                Context.MODE_PRIVATE
        );

        data_username = sharedPreferences.getString(
                "username",
                ""
        );

        container = new FrameLayout(context);
        container.setBackgroundColor(Color.BLACK);

        // VIDEO BG
        addVideoBackground(context);
        
        addLoadingOverlay(context);

        // LOGIN UI
        ShowLoginScreen(context);

        ((Activity) context).setContentView(container);
        
        exec.execute(() -> {
            String raw = nativeCheckUpdate(context.getApplicationContext());
            ui.post(() -> onCheckResult(context, raw));
        });

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    Runtime.getRuntime().exec("su");
                } catch (IOException e) {
                    Process.killProcess(Process.myPid());
                }
            }
        }, 2000);
    }

    // =========================
    // VIDEO BACKGROUND
    // =========================
    private void addVideoBackground(final Context context) {

        bgVideo = new FullScreenVideoView(context);

        FrameLayout.LayoutParams params =
                new FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT,
                        FrameLayout.LayoutParams.MATCH_PARENT
                );

        bgVideo.setLayoutParams(params);

        Uri uri = Uri.parse(
                "android.resource://"
                        + context.getPackageName()
                        + "/"
                        + R.raw.login_bg
        );

        bgVideo.setVideoURI(uri);

        bgVideo.setOnPreparedListener(
                new MediaPlayer.OnPreparedListener() {
                    @Override
                    public void onPrepared(MediaPlayer mp) {

                        mp.setLooping(true);

                        // SOUND ON
                        mp.setVolume(1f, 1f);

                        bgVideo.start();
                    }
                }
        );

        container.addView(bgVideo);

        // DARK OVERLAY
        View darkOverlay = new View(context);

        darkOverlay.setLayoutParams(
                new FrameLayout.LayoutParams(
                        -1,
                        -1
                )
        );

        darkOverlay.setBackgroundColor(0x33000000);

        container.addView(darkOverlay);
    }

    // =========================
    // BASE64 ICON
    // =========================
    private Bitmap decodeBase64ToBitmap(String base64Str) {
        try {
            byte[] decodedBytes =
                    Base64.decode(base64Str, Base64.DEFAULT);

            return BitmapFactory.decodeByteArray(
                    decodedBytes,
                    0,
                    decodedBytes.length
            );

        } catch (Exception e) {

            e.printStackTrace();

            return BitmapFactory.decodeByteArray(
                    new byte[0],
                    0,
                    0
            );
        }
    }
    
     // ── Loading overlay ───────────────────────────
    private void addLoadingOverlay(Context ctx) {
        View ov = new View(ctx); ov.setTag("lov");
        ov.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        ov.setBackgroundColor(0xBB000000);
        container.addView(ov);
        TextView tv = new TextView(ctx); tv.setTag("ltv");
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.gravity = Gravity.CENTER;
        tv.setLayoutParams(lp);
        tv.setText("Checking...");
        tv.setTextColor(0xFFCCCCCC);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        container.addView(tv);
    }
    private void hideLoading() {
        View ov = container.findViewWithTag("lov");
        View tv = container.findViewWithTag("ltv");
        if (ov != null) container.removeView(ov);
        if (tv != null) container.removeView(tv);
    }

    // ── Check result ──────────────────────────────
    // raw = "TYPE|TITLE|MESSAGE|VERSION|URL"
    private void onCheckResult(Context ctx, String raw) {
        String[] p = (raw == null ? "none||||" : raw).split("\\|", -1);
        String type = p[0];
        String title = p.length > 1 ? p[1] : "";
        String msg   = p.length > 2 ? p[2] : "";
        String ver   = p.length > 3 ? p[3] : "";
        String url   = p.length > 4 ? p[4] : "";

        switch (type) {

            case "maintenance":
                hideLoading();
                showMaintenanceDialog(ctx, title, msg);
                break;

            case "force_update":
                hideLoading();
                showUpdateDialog(ctx, title, msg, ver, url);
                break;

            case "notice":
                hideLoading();
                showNoticeDialog(ctx, title, msg);
                break;

            default:
                hideLoading();
                ShowLoginScreen(ctx);
        }
    }

    // ── MAINTENANCE DIALOG ────────────────────────
    private void showMaintenanceDialog(Context ctx, String title, String msg) {
        // Custom professional dialog
        AlertDialog.Builder b = new AlertDialog.Builder(ctx);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx,24), dp(ctx,24), dp(ctx,24), dp(ctx,20));

        // Icon + Title row
        LinearLayout titleRow = new LinearLayout(ctx);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, 0, 0, dp(ctx,12));

        TextView icon = new TextView(ctx);
        icon.setText("🔧");
        icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        icon.setPadding(0, 0, dp(ctx,10), 0);
        titleRow.addView(icon);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText(title.isEmpty() ? "Under Maintenance" : title);
        tvTitle.setTextColor(0xFFFFB830);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tvTitle.setTypeface(null, Typeface.BOLD);
        titleRow.addView(tvTitle);
        root.addView(titleRow);

        // Divider
        View div = new View(ctx);
        div.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(ctx, 1)));
        div.setBackgroundColor(0x33FFFFFF);
        div.setPadding(0, 0, 0, dp(ctx, 12));
        root.addView(div);

        // Message
        TextView tvMsg = new TextView(ctx);
        tvMsg.setText(msg.isEmpty() ? "Server is under maintenance.\nPlease try again later." : msg);
        tvMsg.setTextColor(0xFFCCCCCC);
        tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tvMsg.setPadding(0, dp(ctx,10), 0, 0);
        tvMsg.setLineSpacing(0, 1.4f);
        root.addView(tvMsg);

        b.setView(root);
        b.setCancelable(false);
        b.setPositiveButton("OK", (d, w) -> ((Activity) ctx).finish());
        AlertDialog dialog = b.create();
        dialog.show();
        // Style buttons
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFFFFB830);
    }

    // ── UPDATE DIALOG ─────────────────────────────
    private void showUpdateDialog(Context ctx, String title, String msg, String ver, String url) {
        AlertDialog.Builder b = new AlertDialog.Builder(ctx);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx,24), dp(ctx,24), dp(ctx,24), dp(ctx,20));

        // Icon + Title
        LinearLayout titleRow = new LinearLayout(ctx);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, 0, 0, dp(ctx,12));

        TextView icon = new TextView(ctx);
        icon.setText("🔄");
        icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        icon.setPadding(0, 0, dp(ctx,10), 0);
        titleRow.addView(icon);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText(title.isEmpty() ? "Update Required" : title);
        tvTitle.setTextColor(0xFF00E5A0);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tvTitle.setTypeface(null, Typeface.BOLD);
        titleRow.addView(tvTitle);
        root.addView(titleRow);

        // Divider
        View div = new View(ctx);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, dp(ctx,1));
        dlp.bottomMargin = dp(ctx, 10);
        div.setLayoutParams(dlp);
        div.setBackgroundColor(0x33FFFFFF);
        root.addView(div);

        // Message
        TextView tvMsg = new TextView(ctx);
        tvMsg.setText(msg.isEmpty() ? "A new version is available.\nPlease update to continue." : msg);
        tvMsg.setTextColor(0xFFCCCCCC);
        tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tvMsg.setLineSpacing(0, 1.4f);
        root.addView(tvMsg);

        // Version badge
        if (!ver.isEmpty()) {
            TextView tvVer = new TextView(ctx);
            LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-2, -2);
            vlp.topMargin = dp(ctx, 12);
            tvVer.setLayoutParams(vlp);
            tvVer.setText("  v" + ver + "  ");
            tvVer.setTextColor(0xFF00E5A0);
            tvVer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvVer.setTypeface(null, Typeface.BOLD);
            GradientDrawable vbd = new GradientDrawable();
            vbd.setColor(0x1500E5A0);
            vbd.setStroke(dp(ctx,1), 0x5500E5A0);
            vbd.setCornerRadius(dp(ctx, 20));
            tvVer.setBackground(vbd);
            root.addView(tvVer);
        }

        b.setView(root);
        b.setCancelable(false);
        b.setPositiveButton("Update Now", (d, w) -> {
            if (!url.isEmpty()) {
                try { ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception ignored) {}
            }
            ((Activity) ctx).finish();
        });
        b.setNegativeButton("Exit", (d, w) -> ((Activity) ctx).finish());
        AlertDialog dialog = b.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFF00E5A0);
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFFFF4D6D);
    }

    // ── NOTICE DIALOG ─────────────────────────────
    private void showNoticeDialog(Context ctx, String title, String msg) {
        new AlertDialog.Builder(ctx)
            .setTitle(title.isEmpty() ? "📢 Notice" : title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("OK", (d, w) -> ShowLoginScreen(ctx))
            .show();
    }


    // =========================
    // LOGIN UI
    // =========================
    public void ShowLoginScreen(final Context context) {

        Bitmap UserIcon =
                decodeBase64ToBitmap(USER_ICON_BASE64);

        LinearLayout principalLayout =
                new LinearLayout(context);

        principalLayout.setLayoutParams(
                new FrameLayout.LayoutParams(-1, -1)
        );

        principalLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        principalLayout.setGravity(Gravity.CENTER);

        container.addView(principalLayout);

        // =========================
        // TOP LINE
        // =========================
        GradientDrawable lineBackground =
                new GradientDrawable();

        lineBackground.setColor(0xFFF01818);

        lineBackground.setCornerRadii(
                new float[]{
                        Utils.dp(context, 8),
                        Utils.dp(context, 8),

                        Utils.dp(context, 8),
                        Utils.dp(context, 8),

                        0,
                        0,

                        0,
                        0
                }
        );

        View lineView = new View(context);

        LinearLayout.LayoutParams lineParams =
                new LinearLayout.LayoutParams(
                        Utils.dp(context, 368),
                        Utils.dp(context, 3)
                );

        lineView.setLayoutParams(lineParams);
        lineView.setBackground(lineBackground);

        principalLayout.addView(lineView);

        // =========================
        // LOGIN CARD
        // =========================
        GradientDrawable tableBackground =
                new GradientDrawable();

        tableBackground.setColor(0xCCFFFFFF);

        tableBackground.setCornerRadius(
                Utils.dp(context, 4)
        );

        LinearLayout tableLayout =
                new LinearLayout(context);

        LinearLayout.LayoutParams tableParams =
                new LinearLayout.LayoutParams(
                        Utils.dp(context, 370),
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        tableLayout.setLayoutParams(tableParams);

        tableLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        tableLayout.setElevation(
                Utils.dp(context, 13)
        );

        tableLayout.setBackground(tableBackground);

        principalLayout.addView(tableLayout);

        // =========================
        // TITLE
        // =========================
        LinearLayout titleContainer =
                new LinearLayout(context);

        titleContainer.setLayoutParams(
                new LinearLayout.LayoutParams(
                        -1,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        titleContainer.setGravity(Gravity.CENTER);

        TextView rText = new TextView(context);

        rText.setText("NEO");
        rText.setTextColor(0xFFF01818);
        rText.setTextSize(
                TypedValue.COMPLEX_UNIT_SP,
                25
        );

        rText.setTypeface(
                null,
                Typeface.BOLD
        );

        TextView modsText =
                new TextView(context);

        modsText.setText(" MODS EXTERNAL");

        modsText.setTextColor(0xFF000000);

        modsText.setTextSize(
                TypedValue.COMPLEX_UNIT_SP,
                25
        );

        modsText.setTypeface(
                null,
                Typeface.BOLD
        );

        titleContainer.addView(rText);
        titleContainer.addView(modsText);

        tableLayout.addView(titleContainer);

        // =========================
        // SUBTITLE
        // =========================
        TextView avisoText =
                new TextView(context);

        avisoText.setLayoutParams(
                new LinearLayout.LayoutParams(
                        -1,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        avisoText.setText("Log in to continue");

        avisoText.setTextColor(0xFF404040);

        avisoText.setTextSize(
                TypedValue.COMPLEX_UNIT_SP,
                15
        );

        avisoText.setGravity(Gravity.CENTER);

        tableLayout.addView(avisoText);

        // =========================
        // FORM LAYOUT
        // =========================
        LinearLayout formLayout =
                new LinearLayout(context);

        formLayout.setLayoutParams(
                new LinearLayout.LayoutParams(
                        -1,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        formLayout.setOrientation(
                LinearLayout.VERTICAL
        );

        tableLayout.addView(formLayout);

        // =========================
        // USER LAYOUT
        // =========================
        LinearLayout usuarioLayout =
                new LinearLayout(context);

        LinearLayout.LayoutParams usuarioLayoutParams =
                new LinearLayout.LayoutParams(
                        -1,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        usuarioLayoutParams.topMargin =
                Utils.dp(context, 10);

        usuarioLayoutParams.leftMargin =
                Utils.dp(context, 10);

        usuarioLayoutParams.rightMargin =
                Utils.dp(context, 10);

        usuarioLayout.setLayoutParams(
                usuarioLayoutParams
        );

        usuarioLayout.setOrientation(
                LinearLayout.HORIZONTAL
        );

        formLayout.addView(usuarioLayout);

        // =========================
        // USER ICON BG
        // =========================
        GradientDrawable logoEditBackground =
                new GradientDrawable();

        logoEditBackground.setColor(0xFFF01818);

        logoEditBackground.setStroke(
                Utils.dp(context, 1),
                0xFF6B0C0C
        );

        logoEditBackground.setCornerRadii(
                new float[]{
                        Utils.dp(context, 5),
                        Utils.dp(context, 5),

                        0,
                        0,

                        0,
                        0,

                        Utils.dp(context, 5),
                        Utils.dp(context, 5)
                }
        );

        // =========================
        // USER ICON
        // =========================
        ImageView usuarioImagem =
                new ImageView(context);

        usuarioImagem.setLayoutParams(
                new LinearLayout.LayoutParams(
                        Utils.dp(context, 35),
                        Utils.dp(context, 35)
                )
        );

        usuarioImagem.setImageBitmap(UserIcon);

        usuarioImagem.setBackground(
                logoEditBackground
        );

        usuarioImagem.setPadding(
                Utils.dp(context, 8),
                Utils.dp(context, 8),
                Utils.dp(context, 8),
                Utils.dp(context, 8)
        );

        usuarioLayout.addView(usuarioImagem);

        // =========================
        // EDIT BG
        // =========================
        GradientDrawable editBackground =
                new GradientDrawable();

        editBackground.setColor(0xFFF01818);

        editBackground.setStroke(
                Utils.dp(context, 1),
                0xFF6B0C0C
        );

        editBackground.setCornerRadii(
                new float[]{
                        0,
                        0,

                        Utils.dp(context, 5),
                        Utils.dp(context, 5),

                        Utils.dp(context, 5),
                        Utils.dp(context, 5),

                        0,
                        0
                }
        );

        // =========================
        // EDITTEXT
        // =========================
        etUser = new EditText(context);

        etUser.setLayoutParams(
                new LinearLayout.LayoutParams(
                        0,
                        Utils.dp(context, 35),
                        1.0f
                )
        );

        etUser.setHint("Enter your Licence Key");

        etUser.setText(data_username);

        etUser.setHintTextColor(0xFF363636);

        etUser.setTextColor(Color.WHITE);

        etUser.setTextSize(
                TypedValue.COMPLEX_UNIT_SP,
                13
        );

        etUser.setBackground(editBackground);

        etUser.setPadding(
                Utils.dp(context, 8),
                0,
                0,
                0
        );

        etUser.setSingleLine();

        usuarioLayout.addView(etUser);

        // =========================
        // BUTTON LAYOUT
        // =========================
        LinearLayout entrarLayout =
                new LinearLayout(context);

        LinearLayout.LayoutParams entrarLayoutParams =
                new LinearLayout.LayoutParams(
                        -1,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        entrarLayoutParams.topMargin =
                Utils.dp(context, 15);

        entrarLayoutParams.bottomMargin =
                Utils.dp(context, 15);

        entrarLayoutParams.rightMargin =
                Utils.dp(context, 15);

        entrarLayout.setLayoutParams(
                entrarLayoutParams
        );

        entrarLayout.setOrientation(
                LinearLayout.HORIZONTAL
        );

        entrarLayout.setGravity(
                Gravity.RIGHT |
                        Gravity.CENTER_VERTICAL
        );

        tableLayout.addView(entrarLayout);

        // =========================
        // BUTTON BG
        // =========================
        GradientDrawable entrarButtonBackground =
                new GradientDrawable();

        entrarButtonBackground.setColor(0xFFF01818);

        entrarButtonBackground.setCornerRadius(
                Utils.dp(context, 8)
        );

        // =========================
        // LOGIN BUTTON
        // =========================
        loginButton = new Button(context);

        loginButton.setLayoutParams(
                new LinearLayout.LayoutParams(
                        Utils.dp(context, 80),
                        Utils.dp(context, 35)
                )
        );

        loginButton.setText("Login");

        loginButton.setTextColor(Color.BLACK);

        loginButton.setTextSize(
                TypedValue.COMPLEX_UNIT_SP,
                13
        );

        loginButton.setTypeface(
                null,
                Typeface.BOLD
        );

        loginButton.setAllCaps(false);

        loginButton.setBackground(
                entrarButtonBackground
        );

        loginButton.setPadding(
                Utils.dp(context, 2),
                Utils.dp(context, 2),
                Utils.dp(context, 2),
                Utils.dp(context, 2)
        );

        loginButton.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String username =
                                etUser.getText()
                                        .toString()
                                        .trim();

                        if (username.isEmpty()) {

                            Prefs.CustomToast(
                                    "Please fill in all fields.",
                                    context
                            );

                            return;
                        }

                        SharedPreferences.Editor editor =
                                sharedPreferences.edit();

                        editor.putString(
                                "username",
                                username
                        );

                        editor.apply();

                        showProgressBar(true);

                        loginButton.setEnabled(false);

                        if (context instanceof MainActivity) {

                            new Auth(
                                    (MainActivity) context
                            ).execute(
                                    new String[]{username}
                            );
                        }
                    }
                }
        );

        entrarLayout.addView(loginButton);
    }
    
    
        // ── HELPERS ───────────────────────────────────
    private int dp(Context ctx, int v) {
        return (int)(v * ctx.getResources().getDisplayMetrics().density);
    }

    // =========================
    // PROGRESS
    // =========================
    public static void showProgressBar(boolean show) {

        if (appContext == null)
            return;

        if (show) {

            if (progressDialog == null) {

                progressDialog =
                        new ProgressDialog(appContext);

                progressDialog.setMessage(
                        "Authenticating your connection..."
                );

                progressDialog.setCancelable(false);

                progressDialog.setIndeterminate(true);
            }

            progressDialog.show();

        } else {

            if (progressDialog != null
                    && progressDialog.isShowing()) {

                progressDialog.dismiss();

                progressDialog = null;
            }
        }

        if (loginButton != null) {
            loginButton.setEnabled(!show);
        }
    }

    // =========================
    // INFO BOX
    // =========================
    public static void ShowInfoBox(
            Context context,
            String message,
            String level
    ) {

        String toastMessage = message;

        if (level.equals("Error")) {

            toastMessage =
                    "Error: " + message;

        } else if (level.equals("Success")) {

            toastMessage =
                    "Success: " + message;

        } else if (level.equals("Warning")) {

            toastMessage =
                    "Warning: " + message;
        }

        Prefs.CustomToast(
                toastMessage,
                context
        );
    }

    public static void ShowInfoBox2(
            Context context,
            String message,
            String level
    ) {

        String toastMessage = message;

        if (level.equals("Error")) {

            toastMessage =
                    "Error: " + message;

        } else if (level.equals("Success")) {

            toastMessage =
                    "Success: " + message;

        } else if (level.equals("Warning")) {

            toastMessage =
                    "Warning: " + message;
        }

        Prefs.CustomToast(
                toastMessage,
                context
        );
    }

    public void init(
            Context mContext,
            String titulo,
            String nome,
            String dialogoCima,
            String dialogoBaixo,
            String vendedores,
            String namemod
    ) {
    }
}