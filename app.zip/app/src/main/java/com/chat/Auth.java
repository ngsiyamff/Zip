package com.chat;

import android.app.Activity;
import android.os.AsyncTask;
import android.provider.Settings;
import java.lang.ref.WeakReference;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

public class Auth extends AsyncTask<String, Void, String> {
    private final WeakReference<Activity> activityRef;

    // This method is implemented in your client.cpp
    public native String nativeLogin(String key, String hwid);
    public native void stopSocket();

    public Auth(Activity activity) {
        this.activityRef = new WeakReference<>(activity);
    }

    @Override
    protected void onPreExecute() {
        // Ensure the progress bar is visible before starting
        LoginActivity.showProgressBar(true);
    }

    @Override
    protected String doInBackground(String... params) {
        Activity activity = activityRef.get();
        if (activity == null) return "Context Error";
        
        if (isVpnActive(activity)) {

            try {
              // SOCKET DISCONNECT
                stopSocket();
            } catch (Exception e) {
                e.printStackTrace();
            }

            activity.finishAffinity();
            System.exit(0);

            return "VPN Detected";
        } 


        // params[0] is the username/key entered in the EditText
        String userKey = params[0];

        // Generate HWID using Android ID
        String hwid = Settings.Secure.getString(
                activity.getContentResolver(), 
                Settings.Secure.ANDROID_ID
        );

        // Call the C++ nativeLogin function and return the server's response string
        try {
            return nativeLogin(userKey, hwid);
        } catch (UnsatisfiedLinkError e) {
            return "Library not loaded: " + e.getMessage();
        }
    }

    @Override
    protected void onPostExecute(String result) {
        Activity activity = activityRef.get();
        LoginActivity.showProgressBar(false);

        if (activity == null || result == null) return;

        // The C++ side returns the 'message' field from your PHP.
        // If the PHP returns "Login Success", we proceed.
        if (result.contains("Login Success")) {
            LoginActivity.ShowInfoBox(activity, result, "Success");
            
            // Proceed to the next screen or initialize the menu
            new Initialize(activity);
        } else {
            // Show the error message returned from the server (e.g., "User Doesnt Exist")
            LoginActivity.ShowInfoBox(activity, result, "Error");
        }
    }

    public static boolean isVpnActive(Activity context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Activity.CONNECTIVITY_SERVICE);

        if (cm == null) return false;

        Network[] networks = cm.getAllNetworks();

        for (Network network : networks) {
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);

            if (caps != null &&
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                return true;
            }
        }

        return false;
    }
}
