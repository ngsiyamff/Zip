package com.chat;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.util.Log;

import java.security.MessageDigest;

public final class SignatureCheck {
    private static final String TAG = "SignatureCheck";

    // IMPORTANT: Replace this with your final signed APK certificate SHA-256 hash.
    // Format: uppercase hex, no colon/spaces.
    // Example: A1B2C3D4...
    public static final String EXPECTED_SIGNATURE_SHA256 = "E72F411FCFC41642DDBF8AAC37D4022CBF836AF79E04FC174C222F4D62D68594";

    private SignatureCheck() {}

    public static boolean isValid(Context context) {
        try {
            String current = getSignatureSha256(context);
            if (current == null || current.length() == 0) return false;

            // Keep build usable until you paste your release hash.
            // After replacing EXPECTED_SIGNATURE_SHA256, any re-signed APK will fail.
            if (EXPECTED_SIGNATURE_SHA256.startsWith("PUT_YOUR_")) {
                Log.w(TAG, "EXPECTED_SIGNATURE_SHA256 is not set yet. Current: " + current);
                return true;
            }

            return EXPECTED_SIGNATURE_SHA256.equalsIgnoreCase(current);
        } catch (Throwable t) {
            Log.e(TAG, "Signature check failed", t);
            return false;
        }
    }

    public static String getSignatureSha256(Context context) {
        try {
            PackageManager pm = context.getPackageManager();
            PackageInfo info;
            Signature[] signatures;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                if (info.signingInfo == null) return null;
                signatures = info.signingInfo.hasMultipleSigners()
                        ? info.signingInfo.getApkContentsSigners()
                        : info.signingInfo.getSigningCertificateHistory();
            } else {
                info = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
                signatures = info.signatures;
            }

            if (signatures == null || signatures.length == 0) return null;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(signatures[0].toByteArray());
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) sb.append(String.format("%02X", b));
            return sb.toString();
        } catch (Throwable t) {
            Log.e(TAG, "Cannot read signature", t);
            return null;
        }
    }
    
    public static void killIfInvalid(Context context) {
        if (!isValid(context)) {
          android.widget.Toast.makeText(context, "Signature changed", android.widget.Toast.LENGTH_LONG).show();
          
          android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
          handler.postDelayed(() -> {
              android.os.Process.killProcess(android.os.Process.myPid());
              System.exit(1);
          }, 800);
        }
    }

}
