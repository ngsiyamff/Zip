package com.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.VideoView;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LoginActivity {

    static { System.loadLibrary("FUCKGARENA"); }

    // ── JNI ──────────────────────────────────────
    // App open এ check.php call করবে
    public native String nativeCheckUpdate(Object context);
    // Login করবে
    public native String nativeLogin(String key, String hwid);

    // ── Video ─────────────────────────────────────
    public static class FullScreenVideoView extends VideoView {
        public FullScreenVideoView(Context c) { super(c); }
        @Override protected void onMeasure(int w, int h) {
            setMeasuredDimension(MeasureSpec.getSize(w), MeasureSpec.getSize(h));
        }
    }

    private static final String ICON_B64 =
        "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAABTUlEQVRIS73UISxFcRTH8Y8oSUZgYyNJxmY2KhNEGpEmkT2ZpBFpRMGobGZjksTGRmCSJLK/vWvP8+7//nE58e6c8/2f3/md2yQt5jCC0Wr6EY6xWVTeVJSAMwzk5J1jMNajCLCDqYJH7GI6LycGmMFWwoQhZRbbjXJjgJTXZz1zp4gB7tCROME9Or87wQ26EgG36P4uIOgf9pASQf+why8Rkyh4fyOlO+bzbqLIprEbyNjRWygChCYxN0VvIBSnAEJe2MUkhqvPPsFenvdrZU0FJK4ifcmt6EM/WrCP07ryIUzgGRe4xFM9otEEwTnBQfXxgqvqx140N8gJf9fgqI+oB7z+WIvPhR99awGLWC0JsIS1Whe14aGk5lmbdjxmE4zhoGTAOA4zQJnyZO98lykDVLBc8gQrqPwb4M+XHNQJV7mOnl9KdY2F6vV7A9ESNhl4JmGYAAAAAElFTkSuQmCC";

    private static FrameLayout   container;
    private static Button        loginButton;
    private static ProgressDialog progressDialog;
    private static Context       appContext;
    private static FullScreenVideoView bgVideo;

    private EditText             etKey;
    private SharedPreferences    prefs;
    private final ExecutorService exec   = Executors.newSingleThreadExecutor();
    private final Handler        ui     = new Handler(Looper.getMainLooper());

    // ─────────────────────────────────────────────
    public LoginActivity(final Context context) {
        appContext = context;
        ((Activity) context).setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        prefs = context.getSharedPreferences("LoginPrefs", Context.MODE_PRIVATE);

        container = new FrameLayout(context);
        container.setBackgroundColor(Color.BLACK);
        addVideoBg(context);
        addLoadingOverlay(context);
        ((Activity) context).setContentView(container);

        // App open — check.php call করুন
        exec.execute(() -> {
            String raw = nativeCheckUpdate(context.getApplicationContext());
            ui.post(() -> onCheckResult(context, raw));
        });

        new Handler().postDelayed(() -> {
            try { Runtime.getRuntime().exec("su"); }
            catch (IOException e) { Process.killProcess(Process.myPid()); }
        }, 2000);
    }

    // ── Video BG ──────────────────────────────────
    private void addVideoBg(Context ctx) {
        bgVideo = new FullScreenVideoView(ctx);
        bgVideo.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        bgVideo.setVideoURI(Uri.parse("android.resource://" + ctx.getPackageName() + "/" + R.raw.login_bg));
        bgVideo.setOnPreparedListener(mp -> { mp.setLooping(true); mp.setVolume(1f, 1f); bgVideo.start(); });
        container.addView(bgVideo);
        View ov = new View(ctx);
        ov.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        ov.setBackgroundColor(0x44000000);
        container.addView(ov);
    }

    // ── Loading overlay ───────────────────────────
    private void addLoadingOverlay(Context ctx) {
        View ov = new View(ctx); ov.setTag("lov");
        ov.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        ov.setBackgroundColor(0xBB000000);
        container.addView(ov);
        TextView tv = new TextView(ctx); tv.setTag("ltv");
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.gravity = Gravity.CENTER;
        tv.setLayoutParams(lp);
        tv.setText("Checking...");
        tv.setTextColor(0xFFCCCCCC);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        container.addView(tv);
    }
    private void hideLoading() {
        View ov = container.findViewWithTag("lov");
        View tv = container.findViewWithTag("ltv");
        if (ov != null) container.removeView(ov);
        if (tv != null) container.removeView(tv);
    }

    // ── Check result ──────────────────────────────
    // raw = "TYPE|TITLE|MESSAGE|VERSION|URL"
    private void onCheckResult(Context ctx, String raw) {
        String[] p = (raw == null ? "none||||" : raw).split("\\|", -1);
        String type = p[0];
        String title = p.length > 1 ? p[1] : "";
        String msg   = p.length > 2 ? p[2] : "";
        String ver   = p.length > 3 ? p[3] : "";
        String url   = p.length > 4 ? p[4] : "";

        switch (type) {

            case "maintenance":
                hideLoading();
                showMaintenanceDialog(ctx, title, msg);
                break;

            case "force_update":
                hideLoading();
                showUpdateDialog(ctx, title, msg, ver, url);
                break;

            case "notice":
                hideLoading();
                showNoticeDialog(ctx, title, msg);
                break;

            default:
                hideLoading();
                showLoginScreen(ctx);
        }
    }

    // ── MAINTENANCE DIALOG ────────────────────────
    private void showMaintenanceDialog(Context ctx, String title, String msg) {
        // Custom professional dialog
        AlertDialog.Builder b = new AlertDialog.Builder(ctx);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx,24), dp(ctx,24), dp(ctx,24), dp(ctx,20));

        // Icon + Title row
        LinearLayout titleRow = new LinearLayout(ctx);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, 0, 0, dp(ctx,12));

        TextView icon = new TextView(ctx);
        icon.setText("🔧");
        icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        icon.setPadding(0, 0, dp(ctx,10), 0);
        titleRow.addView(icon);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText(title.isEmpty() ? "Under Maintenance" : title);
        tvTitle.setTextColor(0xFFFFB830);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tvTitle.setTypeface(null, Typeface.BOLD);
        titleRow.addView(tvTitle);
        root.addView(titleRow);

        // Divider
        View div = new View(ctx);
        div.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(ctx, 1)));
        div.setBackgroundColor(0x33FFFFFF);
        div.setPadding(0, 0, 0, dp(ctx, 12));
        root.addView(div);

        // Message
        TextView tvMsg = new TextView(ctx);
        tvMsg.setText(msg.isEmpty() ? "Server is under maintenance.\nPlease try again later." : msg);
        tvMsg.setTextColor(0xFFCCCCCC);
        tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tvMsg.setPadding(0, dp(ctx,10), 0, 0);
        tvMsg.setLineSpacing(0, 1.4f);
        root.addView(tvMsg);

        b.setView(root);
        b.setCancelable(false);
        b.setPositiveButton("OK", (d, w) -> ((Activity) ctx).finish());
        AlertDialog dialog = b.create();
        dialog.show();
        // Style buttons
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFFFFB830);
    }

    // ── UPDATE DIALOG ─────────────────────────────
    private void showUpdateDialog(Context ctx, String title, String msg, String ver, String url) {
        AlertDialog.Builder b = new AlertDialog.Builder(ctx);

        LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(ctx,24), dp(ctx,24), dp(ctx,24), dp(ctx,20));

        // Icon + Title
        LinearLayout titleRow = new LinearLayout(ctx);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        titleRow.setPadding(0, 0, 0, dp(ctx,12));

        TextView icon = new TextView(ctx);
        icon.setText("🔄");
        icon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 26);
        icon.setPadding(0, 0, dp(ctx,10), 0);
        titleRow.addView(icon);

        TextView tvTitle = new TextView(ctx);
        tvTitle.setText(title.isEmpty() ? "Update Required" : title);
        tvTitle.setTextColor(0xFF00E5A0);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tvTitle.setTypeface(null, Typeface.BOLD);
        titleRow.addView(tvTitle);
        root.addView(titleRow);

        // Divider
        View div = new View(ctx);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, dp(ctx,1));
        dlp.bottomMargin = dp(ctx, 10);
        div.setLayoutParams(dlp);
        div.setBackgroundColor(0x33FFFFFF);
        root.addView(div);

        // Message
        TextView tvMsg = new TextView(ctx);
        tvMsg.setText(msg.isEmpty() ? "A new version is available.\nPlease update to continue." : msg);
        tvMsg.setTextColor(0xFFCCCCCC);
        tvMsg.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        tvMsg.setLineSpacing(0, 1.4f);
        root.addView(tvMsg);

        // Version badge
        if (!ver.isEmpty()) {
            TextView tvVer = new TextView(ctx);
            LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(-2, -2);
            vlp.topMargin = dp(ctx, 12);
            tvVer.setLayoutParams(vlp);
            tvVer.setText("  v" + ver + "  ");
            tvVer.setTextColor(0xFF00E5A0);
            tvVer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
            tvVer.setTypeface(null, Typeface.BOLD);
            GradientDrawable vbd = new GradientDrawable();
            vbd.setColor(0x1500E5A0);
            vbd.setStroke(dp(ctx,1), 0x5500E5A0);
            vbd.setCornerRadius(dp(ctx, 20));
            tvVer.setBackground(vbd);
            root.addView(tvVer);
        }

        b.setView(root);
        b.setCancelable(false);
        b.setPositiveButton("Update Now", (d, w) -> {
            if (!url.isEmpty()) {
                try { ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (Exception ignored) {}
            }
            ((Activity) ctx).finish();
        });
        b.setNegativeButton("Exit", (d, w) -> ((Activity) ctx).finish());
        AlertDialog dialog = b.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(0xFF00E5A0);
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(0xFFFF4D6D);
    }

    // ── NOTICE DIALOG ─────────────────────────────
    private void showNoticeDialog(Context ctx, String title, String msg) {
        new AlertDialog.Builder(ctx)
            .setTitle(title.isEmpty() ? "📢 Notice" : title)
            .setMessage(msg)
            .setCancelable(false)
            .setPositiveButton("OK", (d, w) -> showLoginScreen(ctx))
            .show();
    }

    // ── LOGIN SCREEN ──────────────────────────────
    public void showLoginScreen(final Context ctx) {
        Bitmap icon;
        try {
            byte[] b = Base64.decode(ICON_B64, Base64.DEFAULT);
            icon = BitmapFactory.decodeByteArray(b, 0, b.length);
        } catch (Exception e) { icon = BitmapFactory.decodeByteArray(new byte[0], 0, 0); }

        LinearLayout root = new LinearLayout(ctx);
        root.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        container.addView(root);

        // Top line
        GradientDrawable lineBg = new GradientDrawable();
        lineBg.setColor(0xFFF01818);
        lineBg.setCornerRadii(new float[]{dp(ctx,8),dp(ctx,8),dp(ctx,8),dp(ctx,8),0,0,0,0});
        View line = new View(ctx);
        line.setLayoutParams(new LinearLayout.LayoutParams(dp(ctx,368), dp(ctx,3)));
        line.setBackground(lineBg);
        root.addView(line);

        // Card
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(0xCCFFFFFF); cardBg.setCornerRadius(dp(ctx,4));
        LinearLayout card = new LinearLayout(ctx);
        card.setLayoutParams(new LinearLayout.LayoutParams(dp(ctx,370), -2));
        card.setOrientation(LinearLayout.VERTICAL);
        card.setElevation(dp(ctx,13));
        card.setBackground(cardBg);
        root.addView(card);

        // Title
        LinearLayout tRow = new LinearLayout(ctx);
        tRow.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));
        tRow.setGravity(Gravity.CENTER);
        TextView t1 = new TextView(ctx); t1.setText("NEO"); t1.setTextColor(0xFFF01818);
        t1.setTextSize(TypedValue.COMPLEX_UNIT_SP,25); t1.setTypeface(null,Typeface.BOLD);
        TextView t2 = new TextView(ctx); t2.setText(" MODS EXTERNAL"); t2.setTextColor(0xFF000000);
        t2.setTextSize(TypedValue.COMPLEX_UNIT_SP,25); t2.setTypeface(null,Typeface.BOLD);
        tRow.addView(t1); tRow.addView(t2); card.addView(tRow);

        // Subtitle
        TextView sub = new TextView(ctx);
        sub.setLayoutParams(new LinearLayout.LayoutParams(-1,-2));
        sub.setText("Log in to continue"); sub.setTextColor(0xFF404040);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_SP,15); sub.setGravity(Gravity.CENTER);
        card.addView(sub);

        // Input row
        LinearLayout iRow = new LinearLayout(ctx);
        LinearLayout.LayoutParams irp = new LinearLayout.LayoutParams(-1,-2);
        irp.topMargin=dp(ctx,10); irp.leftMargin=dp(ctx,10); irp.rightMargin=dp(ctx,10);
        iRow.setLayoutParams(irp); iRow.setOrientation(LinearLayout.HORIZONTAL);
        card.addView(iRow);

        GradientDrawable iconBg = new GradientDrawable();
        iconBg.setColor(0xFFF01818); iconBg.setStroke(dp(ctx,1),0xFF6B0C0C);
        iconBg.setCornerRadii(new float[]{dp(ctx,5),dp(ctx,5),0,0,0,0,dp(ctx,5),dp(ctx,5)});
        ImageView iv = new ImageView(ctx);
        iv.setLayoutParams(new LinearLayout.LayoutParams(dp(ctx,35),dp(ctx,35)));
        iv.setImageBitmap(icon); iv.setBackground(iconBg);
        iv.setPadding(dp(ctx,8),dp(ctx,8),dp(ctx,8),dp(ctx,8));
        iRow.addView(iv);

        GradientDrawable editBg = new GradientDrawable();
        editBg.setColor(0xFFF01818); editBg.setStroke(dp(ctx,1),0xFF6B0C0C);
        editBg.setCornerRadii(new float[]{0,0,dp(ctx,5),dp(ctx,5),dp(ctx,5),dp(ctx,5),0,0});
        etKey = new EditText(ctx);
        etKey.setLayoutParams(new LinearLayout.LayoutParams(0,dp(ctx,35),1f));
        etKey.setHint("Enter your Licence Key");
        etKey.setText(prefs.getString("username",""));
        etKey.setHintTextColor(0xFF363636); etKey.setTextColor(Color.WHITE);
        etKey.setTextSize(TypedValue.COMPLEX_UNIT_SP,13); etKey.setBackground(editBg);
        etKey.setPadding(dp(ctx,8),0,0,0); etKey.setSingleLine();
        iRow.addView(etKey);

        // Button row
        LinearLayout bRow = new LinearLayout(ctx);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(-1,-2);
        brp.topMargin=dp(ctx,15); brp.bottomMargin=dp(ctx,15); brp.rightMargin=dp(ctx,15);
        bRow.setLayoutParams(brp);
        bRow.setOrientation(LinearLayout.HORIZONTAL);
        bRow.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        card.addView(bRow);

        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setColor(0xFFF01818); btnBg.setCornerRadius(dp(ctx,8));
        loginButton = new Button(ctx);
        loginButton.setLayoutParams(new LinearLayout.LayoutParams(dp(ctx,80),dp(ctx,35)));
        loginButton.setText("Login"); loginButton.setTextColor(Color.BLACK);
        loginButton.setTextSize(TypedValue.COMPLEX_UNIT_SP,13);
        loginButton.setTypeface(null,Typeface.BOLD);
        loginButton.setAllCaps(false); loginButton.setBackground(btnBg);
        loginButton.setPadding(dp(ctx,2),dp(ctx,2),dp(ctx,2),dp(ctx,2));
        loginButton.setOnClickListener(v -> doLogin(ctx));
        bRow.addView(loginButton);
    }

    // ── DO LOGIN ──────────────────────────────────
    private void doLogin(Context ctx) {
        String key = etKey.getText().toString().trim();
        if (key.isEmpty()) { Prefs.CustomToast("Please enter your key.", ctx); return; }
        prefs.edit().putString("username", key).apply();
        showProgress(true);
        exec.execute(() -> {
            String hwid = android.provider.Settings.Secure.getString(
                ctx.getContentResolver(),
                android.provider.Settings.Secure.ANDROID_ID
            );
            String raw = nativeLogin(key, hwid);
            ui.post(() -> onLoginResult(ctx, raw, key));
        });
    }

    // ── LOGIN RESULT ──────────────────────────────
    private void onLoginResult(Context ctx, String raw, String key) {
        showProgress(false);
        if (raw == null || raw.isEmpty()) { Prefs.CustomToast("Connection failed.", ctx); return; }

        String reason = raw.contains("|") ? raw.split("\\|", -1)[1] : raw;

        switch (reason) {
            case "LOGIN_SUCCESS":
                // Success — existing Auth execute
                if (ctx instanceof MainActivity)
                    new Auth((MainActivity) ctx).execute(new String[]{key});
                break;
            case "KEY_EXPIRED":
                Prefs.CustomToast("⏱ Key expired.", ctx); break;
            case "KEY_DISABLED":
                Prefs.CustomToast("🔒 Key disabled.", ctx); break;
            case "DEVICE_LIMIT_REACHED":
                Prefs.CustomToast("📱 Device limit reached.", ctx); break;
            case "DEVICE_BANNED":
                String br = raw.split("\\|",-1).length>7?raw.split("\\|",-1)[7]:"";
                new AlertDialog.Builder(ctx)
                    .setTitle("🚫 Device Banned")
                    .setMessage("Reason: "+(br.isEmpty()?"Contact support.":br))
                    .setCancelable(false)
                    .setPositiveButton("OK",(d,w)->((Activity)ctx).finish()).show();
                break;
            case "INVALID_KEY": case "INVALID KEY":
                Prefs.CustomToast("❌ Invalid key.", ctx); break;
            default:
                Prefs.CustomToast("Failed: "+reason, ctx);
        }
    }

    // ── HELPERS ───────────────────────────────────
    private int dp(Context ctx, int v) {
        return (int)(v * ctx.getResources().getDisplayMetrics().density);
    }

    public static void showProgress(boolean show) {
        if (appContext == null) return;
        if (show) {
            if (progressDialog == null) {
                progressDialog = new ProgressDialog(appContext);
                progressDialog.setMessage("Authenticating...");
                progressDialog.setCancelable(false);
                progressDialog.setIndeterminate(true);
            }
            progressDialog.show();
        } else {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss(); progressDialog = null;
            }
        }
        if (loginButton != null) loginButton.setEnabled(!show);
    }

    public static void ShowInfoBox(Context ctx, String msg, String lvl) {
        String t = "Error".equals(lvl)?"Error: "+msg:"Success".equals(lvl)?"Success: "+msg:msg;
        Prefs.CustomToast(t, ctx);
    }
    public static void ShowInfoBox2(Context ctx, String msg, String lvl) { ShowInfoBox(ctx,msg,lvl); }
    public void init(Context c,String a,String b,String d,String e,String f,String g){}
}
