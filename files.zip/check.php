<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

define('DB_HOST','fdb1033.awardspace.net');
define('DB_USER','4747685_siyam1010');
define('DB_PASS','Siyam@#1010');
define('DB_NAME','4747685_siyam1010');

function db():PDO{static $p=null;if(!$p)$p=new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);return $p;}

$app    = trim($_POST['app']         ?? $_GET['app']         ?? '');
$appver = trim($_POST['app_version'] ?? $_GET['app_version'] ?? '');
if(!$app){echo json_encode(['type'=>'none']);exit;}

$pdo=db();
$as=$pdo->prepare("SELECT id FROM apps WHERE app_slug=? AND is_active=1");
$as->execute([$app]);$ar=$as->fetch(PDO::FETCH_ASSOC);
if(!$ar){echo json_encode(['type'=>'none']);exit;}

$ns=$pdo->prepare("SELECT * FROM app_notices WHERE app_id=? AND is_active=1 ORDER BY id DESC LIMIT 1");
$ns->execute([$ar['id']]);$nr=$ns->fetch(PDO::FETCH_ASSOC);
if(!$nr){echo json_encode(['type'=>'none']);exit;}

$type=$nr['notice_type'];
$title=$nr['title']??'';
$message=$nr['message']??'';
$ver=$nr['update_version']??'';
$url=$nr['update_url']??'';

if($type==='maintenance'){
    echo json_encode(['type'=>'maintenance','title'=>$title,'message'=>$message]);exit;
}
if($type==='update'&&!empty($ver)){
    if(!empty($appver)&&version_compare($appver,$ver,'<')){
        echo json_encode(['type'=>'force_update','title'=>$title,'message'=>$message,'update_version'=>$ver,'update_url'=>$url]);exit;
    }
    echo json_encode(['type'=>'none']);exit;
}
if($type==='normal'){
    echo json_encode(['type'=>'notice','title'=>$title,'message'=>$message]);exit;
}
echo json_encode(['type'=>'none']);
