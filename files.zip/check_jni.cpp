// ================================================
// আপনার existing .cpp file এ এই দুটো function যোগ করুন
// ================================================

// App version auto-detect করবে
static std::string GetAppVersion(JNIEnv *env, jobject context) {
    try {
        jclass ctxClass = env->FindClass("android/content/Context");
        jmethodID getPM = env->GetMethodID(ctxClass, "getPackageManager", "()Landroid/content/pm/PackageManager;");
        jmethodID getPkg = env->GetMethodID(ctxClass, "getPackageName", "()Ljava/lang/String;");
        jobject pm = env->CallObjectMethod(context, getPM);
        jstring pkgName = (jstring) env->CallObjectMethod(context, getPkg);
        jclass pmClass = env->FindClass("android/content/pm/PackageManager");
        jmethodID getPkgInfo = env->GetMethodID(pmClass, "getPackageInfo", "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
        jobject pkgInfo = env->CallObjectMethod(pm, getPkgInfo, pkgName, 0);
        jclass piClass = env->FindClass("android/content/pm/PackageInfo");
        jfieldID verNameField = env->GetFieldID(piClass, "versionName", "Ljava/lang/String;");
        jstring verName = (jstring) env->GetObjectField(pkgInfo, verNameField);
        const char *v = env->GetStringUTFChars(verName, 0);
        std::string result(v);
        env->ReleaseStringUTFChars(verName, v);
        return result;
    } catch (...) {
        return "1.0.0";
    }
}

// check.php call করবে — app open হলে call করুন
// Returns: "TYPE|TITLE|MESSAGE|VERSION|URL"
extern "C"
JNIEXPORT jstring JNICALL
Java_com_chat_LoginActivity_nativeCheckUpdate(JNIEnv *env, jobject thiz, jobject context) {

    std::string appVersion = GetAppVersion(env, context);
    std::string result = "none||||";

    CURL *curl;
    struct MemoryStruct chunk{};
    chunk.memory = (char *) malloc(1);
    chunk.size = 0;

    curl = curl_easy_init();
    if (curl) {
        std::string postData =
            "app=FreeFire"
            "&app_version=" + appVersion;

        curl_easy_setopt(curl, CURLOPT_URL, "https://external.onlinewebshop.net/check.php");
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long) postData.size());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);

        if (curl_easy_perform(curl) == CURLE_OK) {
            try {
                json resp = json::parse(chunk.memory);
                std::string type = resp.value("type",           "none");
                std::string titl = resp.value("title",          "");
                std::string msg  = resp.value("message",        "");
                std::string ver  = resp.value("update_version", "");
                std::string url  = resp.value("update_url",     "");
                result = type+"|"+titl+"|"+msg+"|"+ver+"|"+url;
            } catch (...) {
                result = "none||||";
            }
        }
        curl_easy_cleanup(curl);
    }
    free(chunk.memory);
    return env->NewStringUTF(result.c_str());
}
